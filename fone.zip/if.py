# -*- coding: utf-8 -*-
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-

import LineNeo
from lineNeo.lib.curve.ttypes import *
from datetime import datetime, date, time
from bs4 import BeautifulSoup
import time, random, sys, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, urllib2, wikipedia,tempfile,glob,shutil,unicodedata,goslate
from gtts import gTTS
import requests
from urllib import urlopen
import urllib2
import urllib3
import tempfile
import html5lib

cl = LineNeo.LINE()
cl.login(token="EogJ4JT1neUAyPIBAp1d.bFt/SJvuk3tVrtJBv+kGVq.Ic5764uzOi7/Yv0QFyMwEa6/zI9DsHhJhX3iKMavt3Y=")
cl.loginResult()

ki = LineNeo.LINE()
ki.login(token="EoHcwyLKeew1jO02jyba.KvOD7oCa8IUHCEww4ms8/G.qH4nHVN77XArHtJV38zJh65iJBJX3+CIghMQG31llAI=")
ki.loginResult()

kk = LineNeo.LINE()
kk.login(token="Eo6vpsYy6TB5RFxoUlCe.W4b1Gm7fD2pDiM0+LaWlJG.WXfTj/Ymc063PCfG85oGAojffsEDwh51I1aXFHcopmE=")
kk.loginResult()


kc = kk
print ("NEO READY RUN")
reload(sys)
sys.setdefaultencoding('utf-8')
helpMessage ="""⌯ꏍ⌯༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻⌯ꏍ⌯
⌯ꏍ⌯ COMMENT STANDART ⌯ꏍ⌯
----------------------------------------------------
⌯ꏍ⌯ Me
⌯ꏍ⌯ Id
⌯ꏍ⌯ Mid
⌯ꏍ⌯ Gid
⌯ꏍ⌯ Help
⌯ꏍ⌯ Help2
⌯ꏍ⌯ Gift
⌯ꏍ⌯ Gift1-3
⌯ꏍ⌯ Up
⌯ꏍ⌯ Ginfo
⌯ꏍ⌯ Gourl
⌯ꏍ⌯ Link on
⌯ꏍ⌯ Link off
⌯ꏍ⌯ Creator
⌯ꏍ⌯ Gcreator
⌯ꏍ⌯ Mid mid
⌯ꏍ⌯ Rgroups
⌯ꏍ⌯ Mygroups
⌯ꏍ⌯ G creator
⌯ꏍ⌯ Kick: (mid)
⌯ꏍ⌯ Invite: (mid)
⌯ꏍ⌯ Tl: (text)
⌯ꏍ⌯ Cc: (text)
⌯ꏍ⌯ Message: (text)
⌯ꏍ⌯ Comment: (text)
⌯ꏍ⌯ Myname: (text)
⌯ꏍ⌯ Group name: (text)
⌯ꏍ⌯ Mypmcast: (text)
⌯ꏍ⌯ Mygroupcast: (text)
⌯ꏍ⌯ Update welcome: (text)
⌯ꏍ⌯ Check welcome message
⌯ꏍ⌯ Invite gcreator
⌯ꏍ⌯ Restart
⌯ꏍ⌯ Tagall
⌯ꏍ⌯ Tagmem
⌯ꏍ⌯ Lurk
⌯ꏍ⌯ Lurkers
⌯ꏍ⌯ Point
⌯ꏍ⌯ Readpoint
⌯ꏍ⌯ Quotes
⌯ꏍ⌯ Time
⌯ꏍ⌯ Jam
⌯ꏍ⌯ Run time
⌯ꏍ⌯ Bye bye
⌯ꏍ⌯ All contact
⌯ꏍ⌯ Turn off bots
⌯ꏍ⌯ Cancel invites
---------------------------------------------------
⌯ꏍ⌯   PROMOT / DEMODE   ⌯ꏍ⌯
---------------------------------------------------
⌯ꏍ⌯ Add staff:on
⌯ꏍ⌯ Expel staff:on
⌯ꏍ⌯ Staff:on @
⌯ꏍ⌯ Expel:on @
⌯ꏍ⌯ Staff list
⌯ꏍ⌯ Notag:on/off
⌯ꏍ⌯ Auto chat:on/off
⌯ꏍ⌯ Tag respon:on/off
⌯ꏍ⌯ Talk ban:on/off
⌯ꏍ⌯  
⌯ꏍ⌯
⌯ꏍ⌯
⌯ꏍ⌯ Check @
⌯ꏍ⌯ Copy @
⌯ꏍ⌯ Spam @
⌯ꏍ⌯ Group pic
⌯ꏍ⌯ Cover @
⌯ꏍ⌯ Pp @
⌯ꏍ⌯ Mid @
⌯ꏍ⌯ Steal bio @
⌯ꏍ⌯ Steal group pict
⌯ꏍ⌯ Ban
⌯ꏍ⌯ Unban
⌯ꏍ⌯ Ban:on @
⌯ꏍ⌯ Unban:on @
⌯ꏍ⌯ Block @
⌯ꏍ⌯ Blacklist
⌯ꏍ⌯ Blocklist
⌯ꏍ⌯ Ban:repeat
⌯ꏍ⌯ Unban:repeat
⌯ꏍ⌯ Clear ban
⌯ꏍ⌯ Unbanall
⌯ꏍ⌯ Repeat:off
⌯ꏍ⌯ Clear ban
⌯ꏍ⌯ Cbanlist
⌯ꏍ⌯ Ban cek
⌯ꏍ⌯ Setlastpoint
⌯ꏍ⌯Viewlastseen
⌯ꏍ⌯ 
⌯ꏍ⌯
----------------------------------------------------
     COMMENT BOT      
----------------------------------------------------
⌯ꏍ⌯ Bot help
⌯ꏍ⌯ Say (text)
⌯ꏍ⌯ Bot1/2/3
⌯ꏍ⌯ Bot saya (text)
⌯ꏍ⌯ #welcome
⌯ꏍ⌯ All join
⌯ꏍ⌯ A/B/C
⌯ꏍ⌯ Bye
⌯ꏍ⌯ Bot1 gift
⌯ꏍ⌯ All gift
⌯ꏍ⌯ All gid
⌯ꏍ⌯ Ping
⌯ꏍ⌯ Bot mid
⌯ꏍ⌯ Bot1 creator
⌯ꏍ⌯ Neo qron
⌯ꏍ⌯ Neo qroff
⌯ꏍ⌯ Bot1 glist
⌯ꏍ⌯ Respon
⌯ꏍ⌯ Spam (text)
⌯ꏍ⌯ Pmcast: (text)
⌯ꏍ⌯ Groupcast: (text)
⌯ꏍ⌯ Broadcast: (text)
⌯ꏍ⌯ Bot1 pmcast: (text)
⌯ꏍ⌯ Bot1 groupcast: (text)
⌯ꏍ⌯ Bot1 tl: (text)
⌯ꏍ⌯ Bot1 invite: (mid)
⌯ꏍ⌯ Bot1 update name: (text)
⌯ꏍ⌯ Neo cancel invites
⌯ꏍ⌯ Bot1 rgroups
⌯ꏍ⌯ Bot1 copy @
⌯ꏍ⌯ Bot gurl
⌯ꏍ⌯ Bot1 gourl
⌯ꏍ⌯ Neo1 tagall
----------------------------------------------------
⌯ꏍ⌯ COMMENT KICK  & PROTECT
----------------------------------------------------
⌯ꏍ⌯ Nk: @
⌯ꏍ⌯ Fuck @
⌯ꏍ⌯ Kick @
⌯ꏍ⌯ Tkick @
⌯ꏍ⌯ Kill
⌯ꏍ⌯ Cleanse 
⌯ꏍ⌯ Mayhem
⌯ꏍ⌯ Neo1 kick @
⌯ꏍ⌯ Kill ban
⌯ꏍ⌯ Lurk:on/off
⌯ꏍ⌯ Notag:on\off
⌯ꏍ⌯ Invite:on/off
⌯ꏍ⌯ Backup:on/off
⌯ꏍ⌯ Comment:on/off
⌯ꏍ⌯ Clock:on/off
⌯ꏍ⌯ Share:on/off
⌯ꏍ⌯ Auto chat:on\off
⌯ꏍ⌯ Respon tag:on\off
⌯ꏍ⌯ Contact:on/off
⌯ꏍ⌯ Auto like:on/off
⌯ꏍ⌯ Auto join:on/off
⌯ꏍ⌯ Auto leave:on/off
⌯ꏍ⌯ Auto add:on/off
⌯ꏍ⌯ Welcome:on/off
⌯ꏍ⌯ Gcancel:on/off
⌯ꏍ⌯ Protect:on/off
⌯ꏍ⌯ Autokick:on/off
⌯ꏍ⌯ Protect qr:on/off
⌯ꏍ⌯ Blockinvite:on/off
⌯ꏍ⌯ Protect name:on/off
⌯ꏍ⌯ Protect invite:on/off
⌯ꏍ⌯ Auto purge:on/off
⌯ꏍ⌯ All protect:on/off
------------------------------------------------------
⌯ꏍ⌯✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈
⌯ꏍ⌯༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"""
helpMessage3 ="""🔰 Comment Bot Talk🔰
--------------------------------------
⊶⌬  Hehe
⊶⌬ You
⊶⌬ Sue
⊶⌬ Lol
⊶⌬ Wc
⊶⌬ Wkwk
⊶⌬ Galon
⊶⌬ Huft
⊶⌬ Please
⊶⌬ Haaa
⊶⌬ Hmmm
⊶⌬ #test
⊶⌬ Say (text)
⊶⌬ Bot say (txt)
⊶⌬ Ping
⊶⌬ Bot1/1 gift
⊶⌬ Bot1 up tl:
⊶⌬ Bot2 up tl:
⊶⌬ Timeline: (txt)
⊶⌬ Mimic:on
⊶⌬ Mimic:
⊶⌬ Add: @
⊶⌬ Del: @
⊶⌬ List Target
⊶⌬ Measage:
⊶⌬ Add message:
⊶⌬ Comment:
⊶⌬ Add comment:
⊶⌬ Setlastpoint
⊶⌬ #set
⊶⌬ Point
⊶⌬ Read
⊶⌬ #Cek
⊶⌬ Readpoint
⊶⌬ Block@
⊶⌬ Clear banlist
------------------------------------
⊶⌬ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈
⊶⌬ ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n DETIME TODAY :"""
KAC=[cl,ki,kk,kc]
KAC2=[kc,kk,ki]
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Bots = [mid,Amid,Bmid,Cmid]
creator = ["u05f4feb235542b74ef4538db57f2a0bd"]
admin = ["u05f4feb235542b74ef4538db57f2a0bd","u9abd970b6e01b675bc4b9d132057e354","u915a1dece700f22ba171e596e0c4bcfa","ua218b19150167ccab4e7be0310262678"]

wait = {
    'contact':False,
    'autoJoin':False,
    'autoCancel':{"on":True, "members":1},
    'leaveRoom':False,
    'timeline':True,
    'autoAdd':False,
    "lang":"JP",
    "comment":"Auto like by: ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻",
    "commentOn":True,
    "likeOn":True,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cName":"􀰂􀰂􀰂􀰂􀰂􀠁􀠁􀠁",
    "akaInvite":{},
    "blacklist":{},
    "whitelist":{},
    "rblacklist":{},
    "rdblacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "qr":False,
    "AutoKick":False,
    "Backup":False,
    "blockInviteOn":False,
    "protectCancel":False,
    "lurkingOn":False,
    "welcomeOn":"Welcome To: ",
    "purgeOn":False,
    "welcomeOn":False,
    "protectionOn":False,
    "message":"Thanks for add me ask friends. selfbot by ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™ 🙏🙏THANKS 🙏🙏",
    'welmsg':{},
    "talkblacklist":{},
    "talkwblacklist":False,
    "talkdblacklist":False,
    'detectMention':False,
    'kickMention':False,
    "talkban":False,
    "untalk":False,
    'user-agent':{},
    'search_query':{},
    'atjointicket':False,
    "pnharfbot":{},
    "pname":{},
    "pro_name":{},
    'MENTION':{},
    }
wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }

setTime = {}
setTime = wait2['setTime']

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }

settings = {
    "simiSimi":{}
    }

res = {
    'num':{},
    'us':{},
    'au':{},
}


def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False

contact = cl.getProfile()
mybackup = cl.getProfile()
mybackup.displayName = contact.displayName
mybackup.statusMessage = contact.statusMessage
mybackup.pictureStatus = contact.pictureStatus

contact = ki.getProfile()
backup = ki.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

contact = kk.getProfile()
backup = kk.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

contact = kc.getProfile()
backup = kc.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

def cloneContactProfile(cl, mid):
       contact = cl. getContact(mid)
       profile = cl.getProfile()
       profile.displayName = contact.displayName
       profile.statusMessage = contact.statusMessage
       profile.pictureStatus = contact.pictureStatus
       cl.updateDisplayPicture(profile.pictureStatus)
       return cl.updateProfile(profile)

def cloneContactProfile(ki, Amid):
        contact = ki.getContact(Amid)
        profile = ki.getProfile()
        profile.displayName = contact.displayName
        profile.statusMessage = contact.statusMessage
        profile.pictureStatus = contact.pictureStatus
        ki.updateDisplayPicture(profile.pictureStatus)
        return ki.updateProfile(profile)

def cloneContactProfile(kk, Bmid):
        contact = kk.getContact(Bmid)
        profile = kk.getProfile()
        profile.displayName = contact.displayName
        profile.statusMessage = contact.statusMessage
        profile.pictureStatus = contact.pictureStatus
        kk.updateDisplayPicture(profile.pictureStatus)
        return kk.updateProfile(profile)

def cloneContactProfile(kc, Cmid):
        contact = kc.getContact(Cmid)
        profile = kc.getProfile()
        profile.displayName = contact.displayName
        profile.statusMessage = contact.statusMessage
        profile.pictureStatus = contact.pictureStatus
        kc.updateDisplayPicture(profile.pictureStatus)
        return kc.updateProfile(profile)

def upload_tempimage(client):
     '''
         Upload a picture of a kitten. We don't ship one, so get creative!
     '''
     config = {
         'album': album,
         'name':  'bot auto upload',
         'title': 'bot auto upload',
         'description': 'bot auto upload'
     }

     print("Uploading image... ")
     image = client.upload_from_path(image_path, config=config, anon=False)
     print("Done")
     print()

def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":
             query = "S1B tanysyz"   
         s.headers['user-agent'] = 'Mozilla/5.0'
         url    = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r    = s.get(url, params=params)
         soup = BeautulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi


#agent = {'User-Agent' : "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)"}

def sendImage(self, to_, path):
      M = Message(to=to_,contentType = 1)
      M.contentMetadata = None
      M.contentPreview = None
      M_id = self.Talk.client.sendMessage(0,M).id
      files = {
         'file': open(path, 'rb'),
      }
      params = {
         'name': 'media',
         'oid': M_id,
         'size': len(open(path, 'rb').read()),
         'type': 'image',
         'ver': '1.0',
      }
      data = {
         'params': json.dumps(params)
      }
      r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
      if r.status_code != 201:
         raise Exception('Upload image failure.')
      return True

def translate(to_translate, to_language="auto", language="auto"):
    base_link = "http://translate.google.com/m?hl=%s&sl=%s&q=%s"
    if (six.PY2):
        link = base_link % (to_language, language, urllib.pathname2url(to_translate))
        request = urllib2.Request(link, headers=agent)
        page = urllib2.urlopen(request).read()
    else:
        link = base_link % (to_language, language, urllib.parse.quote(to_translate))
        request = urllib.request.Request(link, headers=agent)
        page = urllib.request.urlopen(request).read().decode("utf-8")
    expr = r'class="t0">(.*?)<'
    result = re.findall(expr, page)
    if (len(result) == 0):
        return (result[0])
    return(result[0])
    
def sendAudioWithURL(self, to_, url):
        path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
        r = requests.get(url, stream=True)
        if r.status_code == 200:
         with open(path, 'w') as f:
            shutil.copyfileobj(r.raw, f)
        else:
         raise Exception('Download audio failure.')
        try:
         self.sendAudio(to_, path)
        except Exception as e:
         raise e
    
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def mention(to,nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nama:
     akh = akh + 2
     aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
     strt = strt + 6
     akh = akh + 4
     bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print("[COMMAND] Tag All")
    try:
      cl.sendMessage(msg)
    except Exception as error:
       print

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for tex in tex:
        for command in commands:
            if string ==command:
                return True
                
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)
    
def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def NOTIFIED_READ_MESSAGE(op):
    print
    try:
        if op.param1 in wait2['readPoint']:
            Name = cl.getContact(op.param2).displayName
            if Name in wait2['readMember'][op.param1]:
                pass
            else:
                wait2['readMember'][op.param1] += "\n・" + Name + datetime.now().strftime(' [%d - %H:%M:%S]')
                wait2['ROM'][op.param1][op.param2] = "・" + Name + " ツ"
        else:
            pass
    except:
        pass

def RECEIVE_MESSAGE(op):
    msg = op.message
    try:
        if msg.contentType == 0:
            try:
                if msg.to in wait2['readPoint']:
                    if msg.from_ in wait2["ROM"][msg.to]:
                        del wait2["ROM"][msg.to][msg.from_]
                else:
                    pass
            except:
                pass
        else:
            pass
    except KeyboardInterrupt:
       sys.exit(0)
    except Exception as error:
        print
        print ("\n\nRECEIVE_MESSAGE\n\n")
        return

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik 😉' % (hours, mins, secs)
    
def bot(op):
    try:
        if op.type == 0:
            return
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)

#def bot(op):
#    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))

        if op.type == 17:
           if wait["welcomeOn"] == True:
              if op.param2 not in Bots:
                 ginfo = cl.getGroup(op.param1)
                 cl.sendText(op.param1,cl.getContact(op.param2).displayName + "\n\n✅▶" + wait["welmsg"]+ "\n✍" + str(ginfo.name) + "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

#-------------------------------------------
        if op.type == 55:
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n・ " + Name + datetime.today().strftime(' [%d - %H:%M:%S]')
                        wait2['ROM'][op.param1][op.param2] = "・ " + Name
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                else:
                    pass
            except:
                pass
#-------------------NOTIFIED_READ_MESSAGE----------------

        if op.type == 55:
         try:
             group_id = op.param1
             user_id=op.param2
             subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
         except Exception as e:
             print(e)

#-------------------------------------BOT BACKUP---------------------------------
        if op.type == 13:
            if op.param3 in mid:
                if op.param2 in admin:
                    cl.acceptGroupInvitation(op.param3)
            if op.param3 in Amid:
                if op.param2 in admin:
                    ki.acceptGroupInvitation(op.param3)
            if op.param3 in Bmid:
                if op.param2 in admin:
                    kk.acceptGroupInvitation(op.param3)
            if op.param3 in Cmid:
                if op.param2 in admin:
                    kc.acceptGroupInvitation(op.param3)
#--------------------------------------------------------
            if op.param3 in mid:
                if op.param2 in Amid:
                    cl.acceptGroupInvitation(op.param3)
            if op.param3 in mid:
                if op.param2 in Bmid:
                    cl.acceptGroupInvitation(op.param3)
            if op.param3 in mid:
                if op.param2 in Cmid:
                    cl.acceptGroupInvitation(op.param3)
#--------------------------------------------------------
            if op.param3 in Amid:
                if op.param2 in mid:
                    ki.acceptGroupInvitation(op.param3)
            if op.param3 in Amid:
                if op.param2 in Bmid:
                    ki.acceptGroupInvitation(op.param3)
            if op.param3 in Amid:
                if op.param2 in Cmid:
                    ki.acceptGroupInvitation(op.param3)
#--------------------------------------------------------
            if op.param3 in Bmid:
                if op.param2 in mid:
                    kk.acceptGroupInvitation(op.param3)
            if op.param3 in Bmid:
                if op.param2 in Amid:
                    kk.acceptGroupInvitation(op.param3)
            if op.param3 in Bmid:
                if op.param2 in Cmid:
                    kk.acceptGroupInvitation(op.param3)
#--------------------------------------------------------
            if op.param3 in Cmid:
                if op.param2 in mid:
                    kc.acceptGroupInvitation(op.param3)
            if op.param3 in Cmid:
                if op.param2 in Amid:
                    kc.acceptGroupInvitation(op.param3)
            if op.param3 in Cmid:
                if op.param2 in Bmid:
                    kc.acceptGroupInvitation(op.param3)
#--------------------------------------------------------
        if op.type == 13:
            if dmid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
                    cl.sendText(op.param1, "Blacklist Detected . . . Whitelist to invite . . ." + "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

#===================================Protect backup====================================
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
               if wait["purgeOn"] == True:
                  klist=[ki,kk,kc]
                  random.choice(klist).kickoutFromGroup(op.param1, [op.param2])
        if op.type == 32:
            if op.param2 not in admin:
                if wait["protectCancel"] == True:
                    try:
                        klist=[cl, ki, kk, kc]
                        random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                        random.choice(klist).inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                       print (e)
        if op.type == 13:
            if op.param2 not in admin:
                if wait["blockInviteOn"] == True:
                   klist=[ki,kc,cl]
                   Inviter = op.param3.replace("",',')
                   InviterX = Inviter.split(",")
                   random.choice(klist).cancelGroupInvitation(op.param1, InviterX)
                   pass
            if op.param2 not in admin:
                if wait["protectCancel"] == True:
                   klist=[kc,kk,ki]
                   random.choice(klist).kickoutFromGroup(op.param1, [op.param2])
                   wait["blacklist"][op.param2] = True
                   f=codecs.open('st2__b.json','w','utf-8')
                   json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                   pass
            if op.param2 not in admin:
              if wait["purgeOn"] == True:
                klist=[ki,kk,kc,cl]
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    random.choice(klist).cancelGroupInvitation(op.param1, matched_list)
                    ki.kickoutFromGroup(op.param1, [op.param2])
                    wait["blacklist"][op.param2] = True
                    f=codecs.open('st2__b.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    kc.sendText(op.param1, "Don't invite Blacklist user!")

        if op.type == 13:
            G = cl.getGroup(op.param1)
            I = G.creator
            if not op.param2 in Bots and admin:
                if wait["protectionOn"] == True:
                    klist=[ki,kk,kc,ks,kt]
                    kicker = random.choice(klist)
                    G = kicker.getGroup(op.param1)
                    if G is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        kicker.cancelGroupInvitation(op.param1, gInviMids)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                        cl.sendText(op.param1,"you are prohibited from inviting-_-")
                        c = Message(to=op.param1, from_=None, text=None, contentType=13)
                        c.contentMetadata={'mid':op.param2}
                        cl.sendMessage(c)
        if op.type == 15:
             if op.param2 in admin:
                random.choice(KAC).inviteIntoGroup(op.param1,[op.param2])
        if op.type == 19:
             if op.param2 in Bots:
                   if op.param3 in admin:
                      random.choice(KAC).inviteIntoGroup(op.param1, [op.param3])
        if op.type == 19:
             if not op.param2 in Bots:
                   if op.param3 in admin:
                      random.choice(KAC).inviteIntoGroup(op.param1, [op.param3])
                      random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
        if op.type == 19:
                if not op.param2 in Bots:
                    try:
                        gs = ki.getGroup(op.param1)
                        gs = kk.getGroup(op.param1)
                        targets = [op.param2]
                        for target in targets:
                           try:
                                wait["blacklist"][target] = True
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                           except:
                            pass
                    except Exception as e:
                        print (e)
                if not op.param2 in Bots and admin:
                  if wait["Backup"] == True:
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                        print (e)

        if op.type == 11:
            if op.param2 not in admin:
              if wait["qr"] == True:
                try:
                    klist=[kc,kk,cl]
                    G = random.choice(klist).getGroup(op.param1)
                    G.preventJoinByTicket = True
                    random.choice(klist).updateGroup(G)
                    G.sendText(op.param1,"Hi " + anu.getContact(op.param2).displayName + "\nDon't Play Code QR Link Please . . . (~_~;)")
                except Exception as e:
                    print (e)
            if op.param2 not in admin:
              if wait["protectionOn"] == True:
                 try:
                     klist=[kk,ki,cl]
                     G = random.choice(klist).getGroup(op.param1)
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                     wait["blacklist"][op.param2] = True
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param3])
                     wait["blacklist"][op.param3] = True
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                 except Exception as e:
                           print (e)
#-----------------------------------------------------------------------
        if op.type == 11:
            if op.param3 == "1":
              if op.param1 in protectname:
                  group = cl.getGroup(op.param1)
              try:
                  group.name = wait["pro_name"][op.param1]
                  cl.updateGroup(group)
                  cl.sendText(op.param1, "Groupname protect now")
                  wait["blacklist"][op.param2] = True
                  f=codecs.open('st2__b.json','w','utf-8')
                  json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
              except Exception as e:
                    print (e)
                    pass

#----------------------------------------------------------------------------
        if op.type == 11:
            if op.param3 == '1':
                if op.param1 in wait['pname']:
                    try:
                        G = cl.getGroup(op.param1)
                    except:
                        try:
                            G = ki.getGroup(op.param1)
                        except:
                            try:
                                G = kk.getGroup(op.param1)
                            except:
                                try:
                                    G = kc.getGroup(op.param1)
                                except:
                                            pass
                    G.name = wait['pro_name'][op.param1]
                    try:
                        cl.updateGroup(G)
                    except:
                        try:
                            ki.updateGroup(G)
                        except:
                            try:
                                kk.updateGroup(G)
                            except:
                                try:
                                    kc.updateGroup(G)
                                except:
                                            pass
                    if op.param2 in ken:
                        pass
                    else:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                            pass
#------------------NOTIFIED_KICKOUT_FROM_GROUP-----------------
        if op.type == 19:
            if wait["AutoKick"] == True:
                try:
                    if op.param3 in Bots:
                        pass
                        if op.param2 in Bots:
                            pass
                        else:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                    if op.param2 not in Bots:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                except:
                    print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                    if op.param2 in wait["blacklist"]:
                            pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            if op.param2 in wait["blacklist"]:
                                pass
                            else:
                                if op.param2 in Bots:
                                    pass
                                else:
                                    wait["blacklist"][op.param2] = True
                                    pass
#-----------------------------------------------------------------
                if mid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                 pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ki.updateGroup(G)
                    Ti = ki.reissueGroupTicket(op.param3)
                    cl.acceptGroupInvitationByTicket(op.param3,Ti)
                    ki.acceptGroupInvitationByTicket(op.param3,Ti)
                    kk.acceptGroupInvitationByTicket(op.param3,Ti)
                    kc.acceptGroupInvitationByTicket(op.param3,Ti)
                    X = cl.getGroup(op.param3)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                if Amid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True

                    X = kk.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1,[op.param3])
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ki.updateGroup(G)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                if Bmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True

                    X = kc.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1,[op.param3])
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kk.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kk.updateGroup(G)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                if Cmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True

                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kc.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kc.updateGroup(G)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True


                if admin in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param2 not in Bots:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            if op.param2 in wait["blacklist"]:
                                pass
                            else:
                                random.choice(KAC).inviteIntoGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    random.choice(KAC).inviteIntoGroup(op.param1,[op.param2])
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)

        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)
        if op.type == 26:
            msg = op.message
            send = msg.to
            if wait["talkban"] == True:
             if msg.from_ in wait["talkblacklist"]:
                try:
                    cl.sendText(send,ki.getContact(msg.from_).displayName + " Jangan Ngomong Njing")
                    cl.kickoutFromGroup(send,[msg.from_])
                except:
                    try:
                        cl.sendText(send,ki.getContact(msg.from_).displayName + " Jangan Ngomong Njing")
                        cl.kickoutFromGroup(send,[msg.from_])
                    except:
                        cl.sendText(send,ki.getContact(msg.from_).displayName + " Jangan Ngomong Njing")
                        ki.kickoutFromGroup(send,[msg.from_])
        
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            send = msg.to
            print(
            " TO: {}\n".format(msg.to),
            "FROM: {}\n".format(msg.from_),
            "TEXT: {}\n".format(msg.text),
            "CONTENT TYPE: {}\n".format(msg.contentType),
            "METADATA: {}\n".format(msg.contentMetadata),
            "TYPE: {}\n".format(msg.toType),
            "MESSAGE ID: {}\n".format(msg.id),
            "DATE: {}\n\n".format(msg.createdTime)
            )
            if msg.contentType == 13:
               if wait["talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["talkblacklist"]:
                        contact = ki.getContact(msg.contentMetadata["mid"])
                        ki.sendText(send,contact.displayName + " Already in Talkban")
                        wait["talkwblacklist"] = False
                    else:
                        wait["talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["talkwblacklist"] = False
                        contact = ki.getContact(msg.contentMetadata["mid"])
                        ki.sendText(send,contact.displayName + " Sukses Add to Talkban")
               elif wait["talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["talkblacklist"]:
                        del wait["talkblacklist"][msg.contentMetadata["mid"]]
                        contact = ki.getContact(msg.contentMetadata["mid"])
                        ki.sendText(send,contact.displayName + " Sukses Delete from Talkban")
                        wait["talkdblacklist"] = False
                    else:
                        wait["talkdblacklist"] = False
                        contact = ki.getContact(msg.contentMetadata["mid"])
                        ki.sendText(send,contact.displayName + " Not In Talkban")

        if op.type == 26:
            msg = op.message
            if msg.to in settings["simiSimi"]:
                if settings["simiSimi"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to, "[Chatbot] " + data['result']['response'].encode('utf-8'))
                                
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = ["Im busy , please leave a message",cName + " Iya apa",cName + " tidur jam segini "," -_-"," is busy", cName + " Ditag bot -,-"," Urgent pc aja" + cName, "Dont tag me Bitch " + cName, " Ape ?" + cName + " ", "  " + cName + " "," Apaan"," Bot sange (-_-)!"]
                     ret_ = "[Auto Respon Tag]\n\n " + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  break            
                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["kickMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = [" ",cName + " ",cName + " "," "," ", cName + " ","  " + cName, " " + cName, " " + cName + " ", " " + cName + " "," "," "]
                     ret_ = "SHUT UP THE FUCK OFF . . ." + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  cl.kickoutFromGroup(msg.to,[msg.from_])
                                  break

        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"already add the acount whitelist . . .")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"decided not to comment")
               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted acount fom the black list.  . .")
                        wait["dblack"] = False
                   else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"It is not in the black list")
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"aded")
               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted")
                        wait["dblacklist"] = False
                   else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"It is not in the black list")


#-------------REPEAT_BAN-------------
               elif wait["rblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"Already in Blacklis now.  . ."+ datetime.today().strftime('%H:%M:%S'))
                        wait["rblacklist"] = True
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["rblacklist"] = True
                        cl.sendText(msg.to,"Succes add the  Black list . . ."+ datetime.today().strftime('%H:%M:%S'))
               elif wait["rdblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Succes add the blacklist . . ."+ datetime.today().strftime('%H:%M:%S'))
                        wait["rdblacklist"] = True
                   else:
                        wait["rdblacklist"] = True
                        cl.sendText(msg.to,"It is not in the black list . . ."+ datetime.today().strftime('%H:%M:%S'))
#-------------REPEAT_BAN-------------
               elif wait["contact"] == True:
                    msg.contentType = 0
                    #cl.sendText(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + msg.contentMetadata["displayName"] + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Message :\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n     ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + contact.displayName + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Mesage:\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
            elif msg.contentType == 16:
                if wait["contact"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URL→\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
            elif msg.text is None:
                return
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "Post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URL→\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)

            elif msg.text is None:
                return
            elif msg.text in ["Help","help"]:
              if msg.from_ in admin:
#                print "\nHelp pick up..."
                if wait["lang"] == "JP":
                    cl.sendText(msg.to, helpMessage + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,helpt)

            elif msg.text in ["Settings","Help2"]:
#                print "\nHelp pick up..."
                if wait["lang"] == "JP":
                    cl.sendText(msg.to, helpMessage2 + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to, helpt)

            elif msg.text in ["Flist"]:
                if msg.from_ in admin:
                    if wait["teman"] == {}:
                        cl.sendText(msg.to,"nothing")
                    else:
                        cl.sendText(msg.to,"Daftar teman teman ku ada dibawah ini")
                        mc = ""
                        for mi_d in wait["teman"]:
                            mc += "->" +cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif msg.text in ["Accept invite"]:
                if msg.from_ in admin:
                    gid = cl.getGroupIdsInvited()
                    _list = ""
                    for i in gid:
                        if i is not None:
                            gids = cl.getGroup(i)
                            _list += gids.name
                            cl.acceptGroupInvitation(i)
                        else:
                            break
                    if gid is not None:
                        cl.sendText(msg.to,"Berhasil terima semua undangan dari grup :\n" + _list)
                    else:
                        cl.sendText(msg.to,"Tidak ada grup yang tertunda saat ini")

            elif ("Gn: " in msg.text):
                if msg.toType == 2:
                    klist=[kc,kk,ki,cl]
                    anu = random.choice(klist)
                    G = anu.getGroup(msg.to)
                    G.name = msg.text.replace("Gn: ","")
                    anu.updateGroup(G)
                else:
                    anu.sendText(msg.to,"Not for use less than group")

            elif "Invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Invite: ","")
                    cl.findAndAddContactsByMid(midd)
                    cl.inviteIntoGroup(msg.to,[midd])
            elif "Bot1 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot1 invite: ","Neo1 invite: ")
                    ki.findAndAddContactsByMid(midd)
                    ki.inviteIntoGroup(msg.to,[midd])
            elif "Bot2 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot2 invite: ","Neo2 invite: ")
                    kk.findAndAddContactsByMid(midd)
                    kk.inviteIntoGroup(msg.to,[midd])
            elif "Bot3 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot3 invite: ","Neo3 invite: ")
                    kc.findAndAddContactsByMid(midd)
                    kc.inviteIntoGroup(msg.to,[midd])
#---------------------------------------------
            elif "Myname:" in msg.text:
                string = msg.text.replace("Myname:","")
                if len(string.decode('utf-8')) <= 10000000000:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"􀜁􀇔􏿿Update Names👉 " + string + "👈 ")
#------------------------------------------------------------------
            elif "1name:" in msg.text:
                string = msg.text.replace("1name:","")
                if len(string.decode('utf-8')) <= 400:
                    profile = ki.getProfile()
                    profile.displayName = string
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#------------------------------------------------------------------
            elif "2name:" in msg.text:
                string = msg.text.replace("2name:","")
                if len(string.decode('utf-8')) <= 400:
                    profile = kk.getProfile()
                    profile.displayName = string
                    kk.updateProfile(profile)
                    kk.sendText(msg.to,"??􀇔􏿿Update Names👉" + string + "👈")
#------------------------------------------------------------------
            elif "3name:" in msg.text:
                string = msg.text.replace("3name:","")
                if len(string.decode('utf-8')) <= 400:
                    profile = kc.getProfile()
                    profile.displayName = string
                    kc.updateProfile(profile)
                    kc.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#------------------------------------------------------------------
            elif "Rname: " in msg.text:
                string = msg.text.replace(" Rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Name " + string + " done")
            elif "Bot1 rname: " in msg.text:
                string = msg.text.replace("Bot1 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = ki.getProfile()
                    profile_B.displayName = string
                    ki.updateProfile(profile_B)
                    ki.sendText(msg.to,"Name " + string + " done")
            elif "Bot2 rname: " in msg.text:
                string = msg.text.replace("Bot2 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kk.getProfile()
                    profile_B.displayName = string
                    kk.updateProfile(profile_B)
                    kk.sendText(msg.to,"Name " + string + " done")
            elif "Bot3 rname: " in msg.text:
                string = msg.text.replace("Bot3 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kc.getProfile()
                    profile_B.displayName = string
                    kc.updateProfile(profile_B)
                    kc.sendText(msg.to,"Name " + string + " done")

            elif msg.text in ["Mybackup"]:
                try:
                    cl.updateDisplayPicture(mybackup.pictureStatus)
                    cl.updateProfile(mybackup)
                    cl.sendText(msg.to, "Backup Sukses Bosqu")
                except Exception as e:
                    cl.sendText(msg.to, str (e))
                    
            elif msg.text in ["Backup"]:
                try:
                    cl.updateDisplayPicture(backup.pictureStatus)
                    cl.updateProfile(backup)
                    cl.updateDisplayPicture(backup.pictureStatus)
                    cl.updateProfile(backup)
                    cl.updateDisplayPicture(backup.pictureStatus)
                    cl.updateProfile(backup)
                    cl.updateDisplayPicture(backup.pictureStatus)
                    cl.updateProfile(backup)
                    cl.updateDisplayPicture(backup.pictureStatus)
                    cl.updateProfile(backup)                   
                    cl.sendText(msg.to, "Backup Sukses Bosqu")
                except Exception as e:
                    cl.sendText(msg.to, str (e))

#---------------------------------------------------------------------------------
            elif "Me" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
            elif "Bot1" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                ki.sendMessage(msg)
            elif "Bot2" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                kk.sendMessage(msg)
            elif "Bot3" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                kc.sendMessage(msg)

            elif "Creator" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': creator}
                cl. sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                cl. sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                cl. sendMessage(msg)
            elif "Bot1 creator" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': creator}
                ki.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                ki.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                ki.sendMessage(msg)
            elif "Bot2 creator" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': creator}
                kk.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                kk.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                kk.sendMessage(msg)
            elif "Bot3 creator" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': creator}
                kc.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                kc.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                kc.sendMessage(msg)

            elif "Check" == msg.text:
                msg.contentType = 13
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                mi = cl.getContact(key1)
                cl. sendText(msg.to, "Waiting . . .")
                cl. sendText(msg.to,"[Your MID]✅   \n\n" + key1 + mi)
                cl. sendText(msg.to, "Sucsess checking. . . .")

            elif "All contact" == msg.text:
                msg.contactType = 13
                msg.contactMetadata = {'mid': Bots}
                cl.sendMessage(msg)
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)


            elif msg.text in ["Gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '2'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift1"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'af2d64ad-ccd2-49fa-8fb4-25ae2836a369',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift2"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'f44b6a1a-bdfa-47f7-a839-e7938eb71aac',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '7'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift3"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '89131c1a-e549-4bd5-9e60-e24de0d2e252',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '10'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Bot1 gift","Neo1 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}
                msg.text = None
                ki.sendMessage(msg)
            elif msg.text in ["Bot2 gift","Neo2 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '8'}
                msg.text = None
                kk.sendMessage(msg)
            elif msg.text in ["Bot3 gift","Neo3 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '9'}
                msg.text = None
                kc.sendMessage(msg)
            elif msg.text in ["Bot4 gift","Neo4 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                kx.sendMessage(msg)
            elif msg.text in ["Allgift","All gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '12'}
                msg.text = None
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)

            elif "Group pict" in msg.text:
              if msg.from_ in admin:
                  group = cl.getGroup(msg.to)
                  path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                  cl.sendImageWithURL(msg.to,path)
            elif "bot:off" in msg.text:
               if msg.from_ in owner:
                 try:
                     import sys
                     sys.exit()
                 except:
                     pass

            elif msg.text.lower() == 'run time':
                eltime = time.time() - mulai
                dan = "Bot sudah berjalan selama "+waktu(eltime)
                cl.sendText(msg.to,dan)

#==================================================================            
            elif msg.text in ["Auto chat:on"]:
                settings["simiSimi"][msg.to] = True
                cl.sendText(msg.to,"Success activated Auto Chat Bot . . .")
                
            elif msg.text in ["Auto chat:off"]:
                settings["simiSimi"][msg.to] = False
                cl.sendText(msg.to,"Success deactived Auto Chat Bot . . .")

            elif msg.text in ["Autorespon:on","Tag respon:on"]:
                wait["detectMention"] = True
                cl.sendText(msg.to,"Auto Respon Turned ON . . .")
                
            elif msg.text in ["Autorespon:off","Tag respon:off"]:
                wait["detectMention"] = False
                cl.sendText(msg.to,"Auto Respon  Turned OFF . .  ")
            
            elif msg.text in ["Notag on","Notag:on"]:
                wait["kickMention"] = True
                cl.sendText(msg.to,"Sock is on the door! Now fuck off . . .")
                
            elif msg.text in ["Notag off","Notag:off"]:
                wait["kickMention"] = False
                cl.sendText(msg.to,"Notag has been deactived . . .")

#==================================================================
            elif "Steal bio" in msg.text:
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                try:
                    cl.sendText(msg.to,contact.statusMessage)
                except:
                    cl.sendText(msg.to,contact.statusMessage)

            elif ("Staff:on " in msg.text):
              if msg.from_ in creator:
                 if msg.toType == 2:
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                            admin.append(target)
                            cl.sendText(msg.to,"Succes Staff Added . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                            print ("[Command]Staff add executed")
                        except:
                            pass
              else:
                   cl.sendText(msg.to,"Command denied . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                   cl.sendText(msg.to,"Owner permission required . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif ("Expel:on " in msg.text):
              if msg.from_ in creator:
                 if msg.toType == 2:
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                            admin.remove(target)
                            cl.sendText(msg.to,"Succes Deleting staff . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                            print ("[Command]Staff remove executed")
                        except:
                            pass
              else:
                   cl.sendText(msg.to,"Command denied . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                   cl.sendText(msg.to,"Owner permission required . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Staff list"]:
                if admin == []:
                    cl.sendText(msg.to,"The StaffList is empty . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"Waiting list...")
                    num=1
                    mc = "╔═══════════════╗\n╟               STAFF LIST\n╚═══════════════╝\n╔═══════════════╗"
                    for mi_d in admin:
                        mc += "\n%i. %s" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc +"\n╚════════════════╝\n╔═══════════════╗\n╟    ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n╚═══════════════╝\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
#                    print "[Command]Stafflist executed"

            elif msg.text in ["Batal","Cancel","Cancel invites","Clean invites"]:
                if msg.toType == 2:
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                        cl. sendText(msg.to,"Done Refusing invites" +  "Total: " [" + sinvitee + "] )
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"No one is inviting . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Not for use less than group  . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Bot cancel","Neo clean invites"]:
                if msg.toType == 2:
                    neo = random.choice(KAC2)
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        neo.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            neo.sendText(msg.to,"No one is inviting . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                        else:
                            neo.sendText(msg.to,"Sorry, nobody absent . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Link on","Ourl","Qron"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        a
                        cl.sendText(msg.to,"Done . . . qr is opened . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"URL is ready open . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Slink on","Neo qron"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr is opened . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        anu.sendText(msg.to,"URL is already open . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Link off","Qroff"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr already opened . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Qr is already close . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Slink off","Neo qroff"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr already opened . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        anu.sendText(msg.to,"Already close . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text == "Ginfo":
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "[Error]"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "Close"
                        else:
                            u = "Open"
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n\n⎆Group ID :\n" + msg.to + "\n\n Group Creator :\n" + gCreator + "\n\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\n\n[Group Members] : [" + str(len(ginfo.members)) + "] user\n[Pending Members] : [" + sinvitee + "] user\n\n QR Status : " + u + "\n\n    ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n\n⎆ Group ID :\n" + msg.to + "\n\n Group Creator :\n" + gCreator + "\n\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .")
            elif msg.text in ["Glist","Mygroups"]:
                gs = cl.getGroupIdsJoined()
                L = "❝Groups List❞\n"
                num=1
                for i in gs:
                    L += "\n%i. %s " % (num, cl.getGroup(i).name + " ➡ " + str(len (cl.getGroup(i).members)))
                    num=(num+1)
                L += "\n\n➽ Total Groups : [ %i ]" % len(gs)
                cl.sendText(msg.to, L + "")
            elif msg.text in ["All gid","Allgid"]:
                gid1 = cl.getGroupIdsJoined()
                gid2 = ki.getGroupIdsJoined()
                gid3 = kk.getGroupIdsJoined()
                gid4 = kc.getGroupIdsJoined()
                G1 = "☆ Group ID ☆\n"
                G2 = "☆ Group ID ☆\n"
                G3 = "☆ Group ID ☆\n"
                G4 = "⭐ Group ID ☆\n"
                for i in gid1:
                    G1 += "⭐ %s\n%s\n" % (cl.getGroup(i).name, i)
                for i in gid2:
                    G2 += "⭐ %s\n%s\n" % (ki.getGroup(i).name, i)
                for i in gid3:
                    G3 += "⭐ %s\n%s\n" % (kk.getGroup(i).name, i)
                for i in gid4:
                    G4 += "⭐ %s\n%s\n" % (kc.getGroup(i).name, i)
                cl.sendText(msg.to, G1 + "\n\n⋙ Groups : [ " + str(len(gid1)) + " ]")
                ki.sendText(msg.to, G2 + "\n\n⋙ Groups : [ " + str(len(gid2)) + " ]")
                kk.sendText(msg.to, G3 + "\n\n⋙ Groups : [ " + str(len(gid3)) + " ]")
                kc.sendText(msg.to, G4 + "\n\n⋙ Groups : [ " + str(len(gid4)) + " ]")
            elif msg.text in ["Bot1glist"]:
                gs = ki.getGroupIdsJoined()
                L = "Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                ki.sendText(msg.to, L + "\n Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot2glist"]:
                gs = kk.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                kk.sendText(msg.to, L + "\n☫ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot3glist"]:
                gs = kc.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                kc.sendText(msg.to, L + "\n✖ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Allglist"]:
                gs1 = cl.getGroupIdsJoined()
                gs2 = ki.getGroupIdsJoined()
                gs3 = kk.getGroupIdsJoined()
                gs4 = kc.getGroupIdsJoined()
                L1 = " Groups List \n"
                L2 = " Groups List \n"
                L3 = " Groups List \n"
                L4 = " Groups List \n"
                for i in gs1:
                    L1 += "║ %s \n" % (cl.getGroup(i).name + " | [ " + str(len (cl.getGroup(i).members)) + " ]")
                for i in gs2:
                    L2 += "║ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                for i in gs3:
                    L3 += "║ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                for i in gs4:
                    L4 += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                cl.sendText(msg.to, L1 + "\n Total Groups : [ " + str(len(gs1)) +" ]")
                ki.sendText(msg.to, L2 + "\n Total Groups : [ " + str(len(gs2)) +" ]")
                kk.sendText(msg.to, L3 + "\n Total Groups : [ " + str(len(gs3)) +" ]")
                kc.sendText(msg.to, L4 + "\n Total Groups : [ " + str(len(gs4)) +" ]")

            elif "Id" == msg.text:
                key = msg.to
                cl.sendText(msg.to, key)
            elif "Mid" == msg.text:
                cl.sendText(msg.to,mid)
            elif "Mid mid" == msg.text:
                cl.sendText(msg.to,mid)
                ki.sendText(msg.to,Amid)
                kk.sendText(msg.to,Bmid)
                kc.sendText(msg.to,Cmid)
            elif "Bot mid" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                cl.sendMessage(msg)

            elif "Wkwk" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "100",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Hehe" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Galon" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "9",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "You" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "7",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Sue" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "105",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Huft" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "104",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Please" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "4",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Haaa" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "3",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Lol" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "110",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Hmmm" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "101",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Wc" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "247",
                                     "STKPKGID": "3",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
#============================================
            elif "Say " in msg.text:
                bctxt = msg.text.replace("Say ","")
                ki.sendText(msg.to,(bctxt))
#				kk.sendText(msg.to,(bctxt))
#				kc.sendText(msg.to,(bctxt))
            elif "Bot say " in msg.text:
                saytxt = msg.text.replace("Bot say ","")
                klist=[kc,kk,ki]
                anu = random.choice(klist)
                anu.sendText(msg.to,(saytxt))
            elif msg.text in ["Neo say hi"]:
                ki.sendText(msg.to,"Hi buddy . . .")
                kk.sendText(msg.to,"Hi buddy . . .")
                kc.sendText(msg.to,"Hi Everybuddy . . .")
            elif msg.text in ["Ping"]:
                ki.sendText(msg.to,"PONG . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
#                kk.sendText(msg.to,"PONG . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
#                kc.sendText(msg.to,"PONG . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["#welcome"]:
                ki.sendText(msg.to,"Selamat datang kakak keceh . . .")
                kk.sendText(msg.to,"No baper no ribet yang penting kita happy . . .")
                kc.sendText(msg.to,"Semoga betah ya kak . . . 😊😘😘")
            elif msg.text in ["Respon","Responsename"]:
                s1 = ki.getProfile()
                ki.sendText(msg.to, s1.displayName)
#                s2 = kk.getProfile()
#                kk.sendText(msg.to, s2.displayName)
#                s3 = kc.getProfile()
#                kc.sendText(msg.to, s3.displayName)

 #============================================
            elif "Broadcast: " in msg.text:
                bctxt = msg.text.replace("Broadcast: ","")
                contact = cl.getAllContactIds()
                for cbc in contact:
                    cl.sendText(cbc,(bctxt))
                    ki.sendText(cbs,(bctxt))
                    kk.sendText(cbs,(bctxt))
                    kc.sendTrxt(cbs,(bctxt))
            elif "Pmcast: " in msg.text:
                bctxt = msg.text.replace("Pmcast: ", "")
                contact = cl.getAllContactIds()
                for cbc in contact:
                    cl.sendText(cbc,(bctxt))
            elif "Bot1 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot1 pmcast: ","Neo1 pmcast: ")
                contact = ki.getAllContactIds()
                for cbc in contact:
                    ki.sendText(cbc,(bctxt))
            elif "Bot2 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot2 pmcast: ","Neo2 pmcast: ")
                contact = kk.getAllContactIds()
                for cbc in contact:
                    kk.sendText(cbc,(bctxt))
            elif "Bot3 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot3 pmcast: ","Neo3 pmcast: ")
                contact = kc.getAllContactIds()
                for cbc in contact:
                    kc.sendText(cbc,(bctxt))
            elif "Groupcast: " in msg.text:
                bctxt = msg.text.replace("Groupcast: ","Gbc: ")
                group = cl.getGroupIdsJoined()
                for gbc in group:
                    cl.sendText(gbc,(bctxt))
                    ki.sendText(gbc,(bctxt))
                    kk.sendText(gbc,(bctxt))
                    kc.sendText(gbc,(bctxt))
            elif "Mygroupcast: " in msg.text:
                bctxt = msg.text.replace("Mygroupcast: ","")
                group = cl.getGroupIdsJoined()
                for gbc in group:
                    cl.sendText(gbc,(bctxt))
            elif "Bot1 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot1 groupcast: ","Neo1 groupcast: ")
                group = ki.getGroupIdsJoined()
                for gbc in group:
                    ki.sendText(gbc,(bctxt))
            elif "Bot2 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot2 groupcast: ","Neo2 groupcast: ")
                group = kk.getGroupIdsJoined()
                for gbc in group:
                    kk.sendText(gbc,(bctxt))
            elif "Bot3 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot3 groupcast: ","Neo3 groupcast: ")
                group = kc.getGroupIdsJoined()
                for gbc in group:
                    kc.sendText(gbc,(bctxt))
#=============================================
            elif msg.text in ["Gcreator","Gc"]:
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)
#=========================================================
            elif "Tl: " in msg.text:
                tl_text = msg.text.replace("Tl: ","Timeline: ")
                cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif "Neo1 tl: " in msg.text:
                tl_text = msg.text.replace("Neo1 tl: ","Neo1 timeline: ")
                ki.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+ki.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])

            elif "Neo2 tl: " in msg.text:
                tl_text = msg.text.replace("Neo2 tl: ","Neo2 timeline: ")
                kk.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+kk.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif "Neo3 tl: " in msg.text:
                tl_text = msg.text.replace("Neo3 tl: ","Neo3 timeline: ")
                kc.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+kc.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])

#-----------------------------------------------
            elif ("Copy @" in msg.text):
                   print ("[COPY] Ok")
                   _name = msg.text.replace("Copy @","Clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "Not found . . .")
                   else:
                       for target in targets:
                            try:
                               cl.cloneContactProfile(target)
                               cl.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot1 copy @" in msg.text):
                   print ("[S1_COPY] Ok")
                   _name = msg.text.replace("Bot1 copy @","Neo1 clone:on @","Bot1 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = ki.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       ki.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               ki.cloneContactProfile(target)
                               ki.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot2 copy @" in msg.text):
                   print ("[S2_COPY] Ok")
                   _name = msg.text.replace("Bot2 copy @","Neo2 copy @","Neo2 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = kk.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       kk.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               kk.cloneContactProfile(target)
                               kk.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot3 copy @" in msg.text):
                   print ("[S3_COPY] Ok")
                   _name = msg.text.replace("Bot3 copy @","Neo3 copy @ ","Neo3 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = kc.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       kc.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               kc.cloneContactProfile(target)
                               kc.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)

            elif msg.text in ["Protect:on","Protect on"]:
                if wait["protectionOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect is already on . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection On . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["protectionOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection On . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protect Already on . . ."+ datetime.today().strftime('%H:%M:%S'))

            elif "Protection:on" == msg.text:
                if msg.to in protection:
                    cl.sendText(msg.to,"already protecting group is on . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["pnharfbot"][msg.to] = cl.getGroup(msg.to).name
                    f=codecs.open('pnharfbot.json','w','utf-8')
                    json.dump(wait["pnharfbot"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    protection.append(msg.to)
                    cl.sendText(msg.to,"Protection is turned on . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif "Protection:off" == msg.text:
                try:
                    if msg.from_ in admin:
                        protection.remove(msg.to)
                        cl.sendText(msg.to,"protecting turned off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"already lower protect . . ."+ datetime.today().strftime('%H:%M:%S'))
                except:
                    pass
#--------------------------------------------------------
            elif msg.text in ["Auto kick:on"]:
                if wait["AutoKick"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to, "Auto kick protect is turn on . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                         clsendText(msg.to,"Protect auto kick turn on . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["AutoKick"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Auto kick is turned On . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already on . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Auto kick:off"]:
                if wait["AutoKick"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to, "Auto kick protect is turn off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                         clsendText(msg.to,"Protect auto kick turn off . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["AutoKick"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Auto kick is turned Off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Protect qr:off","Protect link:off","Qrprotect:off"]:
                if wait["qr"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Qr protect is Already off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection QR Off . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["qr"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR Off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already off . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Protect qr:on","Protect link:on","Qrprotect:on"]:
                if wait["qr"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"protect qr is already on . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection QR On . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["qr"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR On . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protect qr Already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Protect:off","Protect off"]:
                if wait["protectionOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection id already off . .  \n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection Off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["protectionOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection already Off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection is lready off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Blockinvite:on","Blockinvite on"]:
                if wait["blockInviteOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny invite already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["blockInviteOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny Invite Turned On . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Blockinvite:off","Blockinvite off"]:
                if wait["blockInviteOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny invite already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["blockInviteOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny Invite Turned Off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Protect invite on","Protect invite:on"]:
                if wait["protectCancel"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["protectCancel"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Invite on . . . Deny invite 2 turned On . . .\n\n °Warning!!!\n °Call admin for invite members\n °Don't rejected pending members!!!")
            elif msg.text in ["Protect invite:off","Protect invite off"]:
                if wait["protectCancel"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection invite 2 already off . . .an\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["protectCancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Invite 2 is turned Off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif "Protect name:on" in msg.text:
                if msg.to in wait['pname']:
                    cl.sendText(msg.to,"Protact group name is turned on . . . don't chage name in a group you cant kick out from the group. . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"Protect group name already on . . . don't changed name group...  you can kick out from the group .. .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    wait['pname'][msg.to] = True
                    wait['pro_name'][msg.to] = cl.getGroup(msg.to).name
            elif "Protect name:off" in msg.text:
                if msg.to in wait['pname']:
                    cl.sendText(msg.to,"Protect group name is turned off.  . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    del wait['pname'][msg.to]
                else:
                    cl.sendText(msg.to,"Protect group name already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["K on","Contact:on","Contact on","K:on"]:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done contact turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"contact already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . contact turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["K:off","Contact:off","Contact off","K off"]:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Contact turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"contact already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . contact is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Auto join on","Join on","Join:on","Auto join:on"]:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Join off","Auto join off","Auto join:off","Join:off"]:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . auto join is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif "Gcancel " in msg.text:
                try:
                    strnum = msg.text.replace("Gcancel ","Neo Gcancel")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"关了邀请拒绝。要时开请指定人数发送")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + " The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "使人以下的小组用自动邀请拒绝")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")

            elif msg.text in ["Leave:on","Auto leave on","Auto leave:on","Leave on"]:
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto leave is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . Auto leave already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto leave already turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Leave:off","Auto leave off","Auto leave:off","Leave off"]:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto leave is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . auto leave is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Aitu leave already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["共有:オン","Share on","Share:on"]:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . Auto share is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . auto share turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto share already turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["共有:オフ","Share off","Share:off"]:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"done . . . Auto share is off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . Auto share is off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto share already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Auto like on","Like on","Auto like:on"]:
                if wait["likeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already on now . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["likeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn On . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Auto like off","Like off","Auto like:off"]:
                if wait["likeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["likeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Welcome on","Welcome:on","Wc on","Wc:on"]:
                if wait["welcomeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Messages auto welcome is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["welcomeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Welcome off","Welcome:off","Wc off","Wc:off"]:
                if wait["welcomeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome messages is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["welcomeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Tag on"]:
                if wait["tag"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"turned to on")
                else:
                    wait["tag"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"turned to on")
                    else:
                        cl.sendText(msg.to,"already on")
                        
            elif msg.text in ["Tag off"]:
                if wait["tag"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"turned to off")
                else:
                    wait["tag"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"turned to off")
                    else:
                        cl.sendText(msg.to,"already off")

            elif msg.text in ["Auto purge on","Auto purge:on","Purge:on","Purge on"]:
                if wait["purgeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching  already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["purgeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto purge on . . .\n\n °Warning!!!\n °Don't invite member from Blacklist users")
            elif msg.text in ["Auto purge ff","Auto purge:off","Purge:off","Purge off"]:
                if wait["purgeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["purgeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto purge is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Status","Set"]:
#            	print "Setting pick up..."
                md = "⊷⌬SETTINGS ACOUNT⌬⊶\n--------------------------------\n"
                if wait["lurkingOn"] == True: md+="⚗⋟ Lurk : on\n"
                else:md+="⚗⋟ Lurk : off\n"
                if wait["clock"] == True: md+="⚗⋟ Clock : on\n"
                else:md+="⚗⋟ Clock : off\n"
                if wait["timeline"] == True: md+="⚗⋟ Share : on\n"
                else:md+="⚗⋟ Share : off\n"
                if wait["contact"] == True: md+="⚗⋟ Contact : on\n"
                else:md+="⚗⋟ Contact : off\n"
                if wait["autoJoin"] == True: md+="⚗⋟ Auto join : on\n"
                else:md +="⚗⋟ Auto join : off\n"
                if wait["autoAdd"] == True: md+="⚗⋟ Auto add : on\n"
                else:md+="⚗⋟ Auto add : off\n"
                if wait["likeOn"] == True: md+="⚗⋟ Auto Like : on\n"
                else:md+="⚗⋟ Auto Like : off\n"
                if wait["commentOn"] == True: md+="⚗⋟ Comment : on\n"
                else:md+="⚗⋟ Comment : off\n"
                if wait["leaveRoom"] == True: md+="⚗⋟ Auto leave : on\n"
                else:md+="⚗⋟ Auto leave : off\n"
                if wait["welcomeOn"] == True: md+="⚗⋟ Welcome message : on\n"
                else:md+="⚗⋟ Welcome message : off\n"
                if wait["autoCancel"]["on"] == True:md+="⚗⋟ Group cancel panding :" + str(wait["autoCancel"]["members"]) + ": on\n-------------------------------\n⊷⌬SETTINGS PROTECT⌬⊶\n-------------------------------\n"
                else:md +="⚗⋟ Group cancel panding : off\n\n\n⊷⌬SETTINGS PROTECT⌬⊶\n\n"
                if wait["purgeOn"] == True: md+="⚗⋟ Auto purge : on\n"
                else:md+="⚗⋟ Auto purge : off\n"
                if wait["Backup"] == True: md+="⚗⋟ Backup : on\n"
                else:md+="⚗⋟ Backup : off\n"
                if wait["protectCancel"] == True: md+="⚗⋟ Protect invite : on\n"
                else:md+="⚗⋟ Protect invite : off\n"
                if wait["blockInviteOn"] == True: md+="⚗⋟ Block invite : on\n"
                else:md+="⚗⋟ Block invite : off\n"
                if wait["pname"] == True: md+="⚗⋟  Protect name : on\n"
                else:md+="⚗⋟ Protect name : off\n"
                if wait["qr"] == True: md+="⚗⋟ Protect Link : on\n"
                else:md+="⚗⋟ Protect Link : off\n"
                if wait["protectionOn"] == True: md+="⚗⋟ Protection : on\n"
                else:md+="⚗⋟ Protection : off\n"
                if wait["atjointicket"] == True: md+="⚗⋟ Auto join tickets:: on\n--------------------------------\n⊷⌬༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%d - %H:%M:%S]')
                else:md+="⚗⋟ Auto join tickets: off\n---------------------------------\n⊷⌬༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%d - %H:%M:%S]')
                cl.sendText(msg.to,md)
#========================================
            elif msg.text in ["Backup:on","Backup on"]:
                if wait["Backup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backuping member is already on . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Backup is turned On . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["Backup"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup is turned On . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Backuping member is lready on . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Backup:off","Backup off"]:
                if wait["Backup"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backups already swiching  off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Backup is turned Off . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["Backup"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup is turned Off . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Backups is already swiching off . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Rgroups"]:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been rejected . . ."+ datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"All invitation already refusrd . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["S1 rgroups","Bot1 rgroups","Neo1 rgroups"]:
                gid = ki.getGroupIdsInvited()
                for i in gid:
                    ki.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    ki.sendText(msg.to,"All invitations is clean . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    ki.sendText(msg.to, "All invitation already refused . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["S2 rgroups","Bot2 rgroups","Neo2 rgruoups"]:
                gid = kk.getGroupIdsInvited()
                for i in gid:
                    kk.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    kk.sendText(msg.to,"All invitations is clean . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    kk.sendText(msg.to,"All invitation is already refused . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Add:on","Auto add on","Auto add:on","Add on"]:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Done . . . Auto add is turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . Auto add is turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto add Already turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Add:off","Auto add off","Auto add:off","Add off"]:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Done . . . auto add is turned off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto add is turned off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto add Already off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Lurk:on","Lurking on","Cctv:on","Cctv on"]:
                if wait["lurkingOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurkers Already On . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurking Turned On Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["lurkingOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurking Turned On Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurkers Already On . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Lurk:off","Lurking off","Cctv:off","Cctv off"]:
                if wait["lurkingOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurking Turned Off Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["lurkingOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurking Turned Off Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already Off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

#========================================
            elif "Update welcome: " in msg.text:
              if msg.from_ in admin:
                wait["welmsg"] = msg.text.replace("Update welcome: ","")
                cl.sendText(msg.to,"update welcome message succes"+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Check welcome message"]:
              if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"yor bot message\n\n" + wait["welmsg"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as follows。\n\n" + wait["welmsg"])


            elif "Message: " in msg.text:
                wait["message"] = msg.text.replace("Message: ","")
                cl.sendText(msg.to,"message changed . . \n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif "Add message: " in msg.text:
                wait["message"] = msg.text.replace("Add message: ","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"done . . . messages is chage . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Message"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message change to\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as follows。\n\n" + wait["message"])
            elif "Comment: " in msg.text:
                c = msg.text.replace("Comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif "Add comment: " in msg.text:
                c = msg.text.replace("Add comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)

            elif msg.text in ["Comment on","Comment:on"]:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto comment already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Comment off","Comment:off"]:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . Auto commend is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Comment"]:
                cl.sendText(msg.to,"message changed to\n\n" + str(wait["comment"]))
            elif msg.text in ["Gurl"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot gurl"]:
                if msg.toType == 2:
                    anu = random.choice(KAC2)
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        anu.updateGroup(X)
                    gurl = anu.reissueGroupTicket(msg.to)
                    anu.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["G creator"]:
              if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

            elif msg.text in ["All protect:off","All protect off"]:
                wait["protectionOn"] = False
                wait["qr"] = False
                wait["pname"] = False
                wait["Backup"] = False
                wait["blockInviteOn"] = False
                wait["protectCancel"] = False
                cl.sendText(msg.to,"Turn off All Protection . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["All protect:on","All protect on"]:
                wait["protectionOn"] = True
                wait["qr"] = True
                wait["pname"] = True
                wait["Backup"] = True
                wait["blockInviteOn"] = True
                wait["protectCancel"] = True
                cl.sendText(msg.to,"Turn On All Protection . . ."+ datetime.today().strftime('%H:%M:%S'))

#===========================================
            elif "Gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("Gourl: ","")
                    gurl = cl.reissueGroupTicket(gid)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    cl.sendText(msg.to,"Not for use less than group")
            elif "S1 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S1 gourl: ","Bot1 gurl")
                    x = ki.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        ki.updateGroup(x)
                    gurl = ki.reissueGroupTicket(gid)
                    ki.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    ki.sendText(msg.to,"Not for use less than group")
            elif "S2 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S2 gourl: ","Bot2 gurl")
                    x = kk.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        kk.updateGroup(x)
                    gurl = kk.reissueGroupTicket(gid)
                    kk.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    kk.sendText(msg.to,"Not for use less than group")
            elif "S3 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S3 gourl: ","Bot3 gurl")
                    x = kc.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        kc.updateGroup(x)
                    gurl = kc.reissueGroupTicket(gid)
                    kc.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    kc.sendText(msg.to,"Not for use less than group")
            elif msg.text.lower() == 'gcreator':
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

            elif 'lyric ' in msg.text.lower():
              if msg.from_ in admin:
                try:
                    songname = msg.text.lower().replace('lyric ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Lyric Lagu ('
                        hasil += song[0]
                        hasil += ')\n\n'
                        hasil += song[5]
                        cl.sendText(msg.to, hasil)
                except Exception as wak:
                        cl.sendText(msg.to, str(wak))
            elif 'wiki ' in msg.text.lower():
              if msg.from_ in admin:
                  try:
                      wiki = msg.text.lower().replace("wiki ","")
                      wikipedia.set_lang("id")
                      pesan="Title ("
                      pesan+=wikipedia.page(wiki).title
                      pesan+=")\n\n"
                      pesan+=wikipedia.summary(wiki, sentences=1)
                      pesan+="\n"
                      pesan+=wikipedia.page(wiki).url
                      cl.sendText(msg.to, pesan)
                  except:
                          try:
                              pesan="Over Text Limit! Please Click link\n"
                              pesan+=wikipedia.page(wiki).url
                              cl.sendText(msg.to, pesan)
                          except Exception as e:
                              cl.sendText(msg.to, str(e))
            elif msg.text.lower() == 'bot restart':
              if msg.from_ in admin:
                    print ("[Command]Like executed")
                    try:
                        cl.sendText(msg.to,"Restarting...")
                        restart_program()
                    except:
                        cl.sendText(msg.to,"Please wait")
                        restart_program()
                        pass

            elif "Clean chat" in msg.text.lower():
                if msg.from_ in admin:
                    try:
                        cl.removeAllMessages(op.param2)
                        print ("[Command] Remove Chat")
                        cl.sendText(msg.to,"Sukses Menghapus Chat")
                    except Exception as error:
                        print (error)
                        cl.sendText(msg.to,"Error Menghapus Chat")

            elif "Play " in msg.text:
                songname = msg.text.replace(".Play ","")
                params = {"songname":songname}
                r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"Judul : " + song[0] + "\nDurasi : " + song[1])
                    cl.sendText(msg.to,song[4])
                    print ("[Command] Lagu")

            elif "/lagu " in msg.text:
                songname = msg.text.replace("/lagu ","")
                params = {"songname":songname}
                r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"Judul : " + song[0] + "\nDurasi : " + song[1])
                    cl.sendAudioWithURL(msg.to,song[3])
                    print ("[Command] Lagu")

#----------------------------------------------------------------------------
            elif "En: " in msg.text:
                txt = msg.text.replace("En: ","")
                try:
                    gs = goslate.Goslate()
                    trs = gs.translate(txt,'en')
                    cl.sendText(msg.to,trs)
                    print ('[Command] Translate EN')
                except:
                    cl.sendText(msg.to,'Error.')

            elif "Ein: " in msg.text:
                txt = msg.text.replace("Ein: ","")
                try:
                    gs = goslate.Goslate()
                    trs = gs.translate(txt,'id')
                    cl.sendText(msg.to,trs)
                    print ('[Command] Translate ID')
                except:
                    cl.sendText(msg.to,'Error.')
#--------------------------------- INSTAGRAM --------------------------------
            elif "Ig " in msg.text:
                arg = msg.text.split(' ');
                nk0 = msg.text.replace("/ig ","")
                nk1 = nk0.rstrip('  ')
                if len(arg) > 1:
                    proc = subprocess.Popen('curl -s https://www.instagram.com/'+nk1+'/?__a=1',shell=True, stdout=subprocess.PIPE)
                    x = proc.communicate()[0]
                    parsed_json = json.loads(x)
                    if(len(x) > 10):
                        username = (parsed_json['user']['username'])
                        fullname = (parsed_json['user']['full_name'])
                        followers = (parsed_json['user']['followed_by']['count'])
                        following = (parsed_json['user']['follows']['count'])
                        media = (parsed_json['user']['media']['count'])
                        bio = (parsed_json['user']['biography'])
                        url = (parsed_json['user']['external_url'])
                        cl.sendText(msg.to,"Profile "+username+"\n\nUsername : "+username+"\nFull Name : "+fullname+"\nFollowers : "+str(followers)+"\nFollowing : "+str(following))
                        print ('[Command] Instagram')
                    else:
                        cl.sendText(msg.to,"Not Found...")
                else:
                    cl.sendText(msg.to,"Contoh /ig hairu.ones")

            elif "Youtube" in msg.text:
                 query = msg.text.replace("Youtube","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'http://www.youtube.com' + a['href'] + a['title'])

            elif "Lihat @" in msg.text:
                nama = msg.text.replace("Lihat @","")
                target = nama.rstrip(' ')
                van = cl.getGroup(msg.to)
                for linedev in van.members:
                    if target == linedev.displayName:
                        midddd = cl.getContact(linedev.mid)
                        PATH = "http://dl.profile.line-cdn.net/" + midddd.pictureStatus
                    cl.sendImageWithURL(msg.to,PATH)

#==================================================
            elif msg.text in ["Invite on","Invite:on"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    cl.sendText(msg.to,"Send a contact to invite . . ."+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Invite stop","Invite:stop"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    cl.sendText(msg.to,"Invite Stoped . . ."+ datetime.today().strftime('%H:%M:%S'))
#========================================
            elif msg.text in ["Comment bl "]:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wl "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist s")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "・" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)

            elif msg.text in ["Clock:on","Clock on","Jam on","Jam:on"]:
                if wait["clock"] == True:
                    cl.sendText(msg.to,"Clock is already on . . .")
                else:
                    wait["clock"] = True
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"done . . .")

            elif msg.text in ["Clock:off","Clock off","Jam off","Jam:off"]:
                if wait["clock"] == False:
                    cl.sendText(msg.to,"Clock name already off . . .")
                else:
                    wait["clock"] = False
                    cl.sendText(msg.to,"done . . . clock name is turned off . . .")

            elif "Cc: " in msg.text:
                n = msg.text.replace("Cc: ","Update name: ","Myname: ")
                if len(n.decode("utf-8")) > 13:
                    cl.sendText(msg.to,"Sucsess name already changed . . .")
                else:
                    wait["cName"] = n
                    cl.sendText(msg.to,"Changed to:\n\n" + n)
            elif msg.text in ["Up"]:
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Refresh to update name done . . .")
                else:
                    cl.sendText(msg.to,"Please turn on the name clock . . .")
#-------------------------------------------------------------------
            elif "Cover @" in msg.text:
                if msg.toType == 2:
                  if msg.from_ in admin:
                    cover = msg.text.replace("Cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print (error)
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Pp @" in msg.text:
                if msg.toType == 2:
                  if msg.from_ in admin:
                    cover = msg.text.replace("Pp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print (error)
                                cl.sendText(msg.to,"Upload image failed.")

#-----------------------------------------------------------------
            elif "Bot1 clone " in msg.text:
              if msg.from_ in admin:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        contact = ki.getContact(target)
                        X = contact.displayName
                        profile = ki.getProfile()
                        profile.displayName = X
                        ki.updateProfile(profile)
                        ki.sendText(msg.to, "Success...")
                        #---------------------------------------
                        Y = contact.statusMessage
                        lol = ki.getProfile()
                        lol.statusMessage = Y
                        ki.updateProfile(lol)
                        #---------------------------------------
                        P = contact.pictureStatus
                        ki.updateProfilePicture(P)
                    except Exception as e:
                        ki.sendText(msg.to, "Failed!")
                        print (e)
            elif "Bot2 clone " in msg.text:
              if msg.from_ in admin:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        contact = kk.getContact(target)
                        X = contact.displayName
                        profile = kk.getProfile()
                        profile.displayName = X
                        kk.updateProfile(profile)
                        kk.sendText(msg.to, "Success...")
                        #---------------------------------------
                        Y = contact.statusMessage
                        lol = kk.getProfile()
                        lol.statusMessage = Y
                        kk.updateProfile(lol)
                        #---------------------------------------
                        P = contact.pictureStatus
                        kk.updateProfilePicture(P)
                    except Exception as e:
                        kk.sendText(msg.to, "Failed!")
                        print (e)
            elif "Bot3 clone " in msg.text:
              if msg.from_ in admin:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        contact = kc.getContact(target)
                        X = contact.displayName
                        profile = kc.getProfile()
                        profile.displayName = X
                        kc.updateProfile(profile)
                        kc.sendText(msg.to, "Success...")
                        #---------------------------------------
                        Y = contact.statusMessage
                        lol = kc.getProfile()
                        lol.statusMessage = Y
                        kc.updateProfile(lol)
                        #---------------------------------------
                        P = contact.pictureStatus
                        kc.updateProfilePicture(P)
                    except Exception as e:
                        kc.sendText(msg.to, "Failed!")
                        print (e)
#--------------------------------------------------------
            elif msg.text in ["Lurk","Lurkpoint"]:
               if wait["lurkingOn"] == True:
                 if msg.toType == 2:
                    cl.sendText(msg.to, "Set lurking point . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    print (wait)
            elif msg.text in ["Lurkers","Lurkcheck"]:
               if wait["lurkingOn"] == True:
                 if msg.toType == 2:
#                    print "\nSider check aktif..."
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to, "[LURKER LIST]\n%s\n\nThese users have seen at the last lurking point . . .\n\n%s" % (wait2['readMember'][msg.to],setTime[msg.to]))
                        wait["lurkingOn"] = True
#                        print "\nReading Point Set..."
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        cl.sendText(msg.to, "Auto set lurking point . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to, "Set reading point first.  . ."+ datetime.today().strftime('%H:%M:%S'))
#========================================
            elif msg.text in ["#set","Point"]:
                 if msg.toType == 2:
                    cl.sendText(msg.to, "Set reading point . . ."+ datetime.today().strftime('%H:%M:%S'))
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    print (wait)
            elif msg.text in ["Read","#Cek","Readpoint"]:
                 if msg.toType == 2:
#                    print "\nSider check aktif..."
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to,"╔════════════════╗\n╟    CHACKING SIDER\n╚════════════════╝\n%s\n╚════════════════╝\n╔════════════════╗\n╟   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n╚════════════════╝\n╔════════════════╗\n%s\n╚════════════════╝\n╔════════════════╗\n╟   In the last seen point:\n╟   [%s]\n╚════════════════╝\n" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
#                        print "\nReading Point Set..."
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        cl.sendText(msg.to, "Auto set reading point . . ."+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to, "Set reading point first . . ."+ datetime.today().strftime('%H:%M:%S'))
#-----------------------------------------------

            elif msg.text in ["Jam","hari","Jam berapa sekarang","Hari"]:
                cl.sendText(msg.to, "Current time is\n" + datetime.today().strftime('🕛%I:%M %p'))


            elif "Berapa besar cinta" in msg.text:
                tanya = msg.text.replace("Berapa besar cinta","")
                jawab = ("10%","20%","30%","40%","50%","60%","70%","80%","90%","100%")
                jawaban = random.choice(jawab)
                ke.sendText(msg.to,"Besar cinta " + tanya + "adalah" + jawaban)
            
            elif msg.text in ["#Time","#Waktu"]:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bulan = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bulan == str(k): bulan = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + bulan + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)

#========================================
            elif msg.text in ["DZion","Kicker","Neo join","All join"]:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        kc.updateGroup(G)
#                        print "All_Kickers_Ok!"
                        G.preventJoinByTicket(G)
                        kc.updateGroup(G)
            elif msg.text in ["S1 join","S1 hadir","Bot1 join","A"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ki.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ki.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
#                  print "Kicker1_Ok!"
                  Ticket = ki.reissueGroupTicket(msg.to)
            elif msg.text in ["S2 join","S2join","B","Bot2 join"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kk.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kk.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kk.updateGroup(G)
#                  print "Kicker2_Ok!"
                  Ticket = kk.reissueGroupTicket(msg.to)
            elif msg.text in ["S3 join","S3join","C","Bot3 join"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kc.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kc.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kc.updateGroup(G)
#                  print "Kicker3_Ok!"
                  Ticket = kc.reissueGroupTicket(msg.to)

            elif msg.text in ["Bye all","Pulang","DZion @bye","Keluar","Bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    ki.leaveGroup(msg.to)
                    kk.leaveGroup(msg.to)
                    kc.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S1 @bye","S1bye","Bot1 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    ki.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S2 @bye","S2bye","Bot2 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    kk.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S3 @bye","S3bye","Bot3 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    kc.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["Bye me","Bye bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    cl.leaveGroup(msg.to)
                except:
                    pass
#-------Cek sider biar mirip kek siri-----------------------------
            elif "Setlastpoint" in msg.text:
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                #cl.sendText(msg.to, "Checkpoint checked!")
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
#                print "Setlastpoint"
#--------------------------------------------
            elif "Viewlastseen" in msg.text:
                lurkGroup = ""
                dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%d日 %H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        grp = '\n• '.join(str(f) for f in dataResult)
                        total = '\n\nThese %i\n\n----------------------------------\nuesrs have seen at the lastseen\npoint(｀・ω・´)\n\n%s' % (len(dataResult), datetime.now().strftime('%H:%M:%S') )
                        cl.sendText(msg.to, "• %s %s" % (grp, total))
                    else:
                        cl.sendText(msg.to, "Sider ga bisa di read cek setpoint dulu bego tinggal ketik\nSetlastpoint\nkalo mau liat sider ketik\nViewlastseen")
#                    print "Viewlastseen"
#==========================================

#---------------------------------------------
            
            elif 'talkban ' in msg.text.lower():
                spl = msg.text.lower().replace('talkban ','')
                if spl == 'on':
                    if wait['talkban'] == True:
                        msgs="Talkban already Not For chat"
                    else:
                        msgs="Talkban set to Not For chat"
                        wait['talkban']=True
                    cl.sendText(msg.to, msgs)
                elif spl == 'off':
                    if wait['talkban'] == False:
                        msgs="Talkban already Allow For chat"
                    else:
                        msgs="Talkban set to Allow For chat"
                        wait['talkban']=False
                    cl.sendText(msg.to, msgs)

            elif "Talkban" in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        wait["talkblacklist"][target] = True
                        group = cl.getContact(target)
                        cl.sendText(msg.to,group.displayName + " Succes Add to Talckban.")
                    except:
                        cl.sendText(msg.to,"Error")
            
            elif "Untalk" in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        del wait["talkblacklist"][target]
                        group = cl.getContact(target)
                        cl.sendText(msg.to,group.displayName + " Deleted from talkban.")
                    except:
                        cl.sendText(msg.to,group.displayName + " Not in talkban")
                    
            
#---------------------------------------
            elif "Mk:" in msg.text:
                  if msg.from_ in admin:
                       mk0 = msg.text.replace("Mk:","")
                       mk1 = mk0.lstrip()
                       mk2 = mk1.replace("@","")
                       mk3 = mk2.rstrip()
                       _name = mk3
                       gs = ki.getGroup(msg.to)
                       targets = []
                       for h in gs.members:
                           if _name in h.displayName:
                              targets.append(h.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist . . .")
                           pass
                       else:
                           for target in targets:
                               try:
                                 if msg.from_ not in target:
                                   ki.kickoutFromGroup(msg.to,[target])
                               except:
                                   pass
#==========================================
            elif msg.text in ["Kill"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    kicker = random.choice(klist)
                    group = kicker.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        ki.sendText(msg.to,"Fuck You")
                        kk.sendText(msg.to,"Fuck You")
                        return
                    for jj in matched_list:
                        try:
                            random.choice(KAC2).kickoutFromGroup(msg.to,[jj])
#                            print (msg.to,[jj])
                        except:
                            pass
            elif "Cleanse" in msg.text:
                if msg.toType == 2:
#                    print "ok"
                    _name = msg.text.replace("Cleanse","")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    cl.sendText(msg.to,"􂀁􀄃explosion􏿿 Just some casual cleansing 􂀁􀄃explosion􏿿")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found.")
                    else:
                        for target in targets:
                          if not target in Bots:
                            try:
                               random.choice(KAC).kickoutFromGroup(msg.to,[target])
#                               print (msg.to,[g.mid])
                            except:
                                pass

            elif ("Mayhem" in msg.text):
                if msg.toType == 2:
#                    print "[CleanAll]ok"
                    _name = msg.text.replace("Mayhem","")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    ki.sendText(msg.to,"􂀁􀄃explosion  KILLING ALL MEMBER 􂀁􀄃explosion􏿿")
                    kk.sendText(msg.to," Mayhem . . .\n Mayhem is STARTING♪\n 'abort' to abort♪")
                    kc.sendText(msg.to," Mayhem . . .\n 46 victims shall yell hul·la·ba·loo♪\n /ˌhələbəˈlo͞o,ˈhələbəˌlo͞o/")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found.")
                    else:
                        for target in targets:
                          if not target in Bots:
                            try:
                                kicker = random.choice(KAC)
                                kicker.kickoutFromGroup(msg.to,[target])
#                                print (msg.to,[g.mid])
                            except:
                                pass

            elif ("Nk" in msg.text):
              if msg.from_ in admin:
                 if msg.toType == 2:
#                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                          if msg.from_ not in target:
                            random.choice(KAC2).kickoutFromGroup(msg.to,[target])
#                            print (msg.to,[g.mid])
                        except:
                            cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif ("Fuck" in msg.text):
              if msg.from_ in admin:
                 if msg.toType == 2:
#                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                          if msg.from_ not in target:
                            cl.kickoutFromGroup(msg.to,[target])
#                            print (msg.to,[g.mid])
                        except:
                            cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif "Kick" in msg.text:
              if msg.from_ in admin:
                 if msg.toType == 2:
#                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                          if msg.from_ not in target:
                            cl.kickoutFromGroup(msg.to,[target])
#                            print (msg.to,[g.mid])
                        except:
                            cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif "Tkick" in msg.text:
                if msg.toType == 2:
#                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                          if msg.from_ not in target:
                            cl.kickoutFromGroup(msg.to,[target])
#                            print (msg.to,[g.mid])
                        except:
                            cl.sendText(msg,to, " Good bye . . . SORRY . . .")
#----------------------------------------------------------------
            elif "Neo1 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           ki.kickoutFromGroup(msg.to,[target])
                       except:
                           ki.sendText(msg.to,"Error")
            elif ("Neo2 kick" in msg.text):
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           kk.kickoutFromGroup(msg.to,[target])
                       except:
                           kk.sendText(msg.to,"Error")
            elif "Neo3 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           kc.kickoutFromGroup(msg.to,[target])
                       except:
                           kc.sendText(msg.to,"Error")
#-----------------------------------------------------------------
            elif msg.text in ["Mimic on","mimic on"]:
                    if wait3["copy"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Already on")
                        else:
                            cl.sendText(msg.to,"Mimic On")
                    else:
                    	wait3["copy"] = True
                    	if wait["lang"] == "JP":
                    	    cl.sendText(msg.to,"Mimic On")
                    	else:
    	                	cl.sendText(msg.to,"Already on")
            elif msg.text in ["Mimic off","mimic:off"]:
                    if wait3["copy"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Already on")
                        else:
                            cl.sendText(msg.to,"Mimic Off")
                    else:
                    	wait3["copy"] = False
                    	if wait["lang"] == "JP":
                    	    cl.sendText(msg.to,"Mimic Off")
                    	else:
	                    	cl.sendText(msg.to,"Already on")
            elif msg.text in ["Target list"]:
                        if wait3["target"] == {}:
                            cl.sendText(msg.to,"nothing")
                        else:
                            mc = "Target mimic user\n"
                            for mi_d in wait3["target"]:
                                mc += "✔️ "+cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif "Mimic target " in msg.text:
                        if wait3["copy"] == True:
                            siapa = msg.text.replace("Mimic target ","")
                            if siapa.rstrip(' ') == "me":
                                wait3["copy2"] = "me"
                                cl.sendText(msg.to,"Mimic change to me")
                            elif siapa.rstrip(' ') == "target":
                                wait3["copy2"] = "target"
                                cl.sendText(msg.to,"Mimic change to target")
                            else:
                                cl.sendText(msg.to,"I dont know")
            elif "Target @" in msg.text:
                        target = msg.text.replace("Target @","")
                        gc = cl.getGroup(msg.to)
                        targets = []
                        for member in gc.members:
                            if member.displayName == target.rstrip(' '):
                                targets.append(member.mid)
                        if targets == []:
                            cl.sendText(msg.to, "User not found")
                        else:
                            for t in targets:
                                wait3["target"][t] = True
                            cl.sendText(msg.to,"Target added")
            elif "Del target @" in msg.text:
                        target = msg.text.replace("Del target @","")
                        gc = cl.getGroup(msg.to)
                        targets = []
                        for member in gc.members:
                            if member.displayName == target.rstrip(' '):
                                targets.append(member.mid)
                        if targets == []:
                            cl.sendText(msg.to, "User not found")
                        else:
                            for t in targets:
                                del wait3["target"][t]
                            cl.sendText(msg.to,"Target deleted")
#====================================================================

#-----------------------------------------------
            elif msg.text in ["Quotes","Quote"]:
                quote = ['Good friends are like stars you dont always see them but they are always there\n\nQuotes by bagas','dreams are like stars you may never catch them but if you follow them they will lead you to your destiny\n\nQuotes by bagas','jangan pernah lupain temen terbaik karna teman terbaik tidak datang 2 kali tolong ingat keseruan keseruan kita dulu\n\nQuotes by  􀜁􀇔􏿿􀜁􀇔􏿿   B̸̛̰̞̣̠͓͖͚̽̏̉̍͌͒̅̈́̋̕͠Å̶̧̛̱͓̦͈͍̭͚Ĝ̵̵̛͚͈̠̟͎̝̪͖͉̺̜͕̤͓͈̟͑̎̎̐̀̃͐̏̓̍͂̏͋͋̄́̓͌ͅȀ̵͖̲̥̜̣̞̔̀̽̀̆́̐͐́̚͘ͅS̷̨̨̫̞̭͔̖̳͍͔̗̰͚̺̋̿͛͒̏͜͝  B̵̺̦̦̫̦͉̳̜͋̃̅̎͒̇̚͞͠ǫ͈̮̼͍̙̰̜̔̀͛̀̐͌͟͡͝t̶̨͓̰̩̎͐̀͑̋̋͢͠     􀜁􀇔􏿿􀜁􀇔􏿿 ']
                psn = random.choice(quote)
                cl.sendText(msg.to,psn)
            elif msg.text in ["Pagi","Morning","pagi","morning"]:
                pagi = ['Selamat pagi semua selamat beraktivitas ya\n','Pagi jangan lupa sarapan ya karna pura pura bahagia juga butuh energi\n','Pagi pagi enaknya ngupi sambil stalking stalking mantan\n']
                psn = random.choice(pagi)
                cl.sendText(msg.to,psn)

            elif msg.text in ["pap","Pap"]:
                        cl.sendImageWithURL(msg.to, "https://images.google.co.id/imgres?imgurl=https%3A%2F%2F3.bp.blogspot.com%2F-VjvtpFc4mak%2FVz_WuJ_x3uI%2FAAAAAAAAAEI%2FXY9UICe817094VN-vezO7jUhKsRrEHU3wCLcB%2Fs1600%2Fhqdefault.jpg&imgrefurl=http%3A%2F%2Fmbahbeni.blogspot.com%2F2016%2F05%2Fhantu-mata-besar-di-bawah-pohon-besar.html&docid=0eICNlm6uAAzbM&tbnid=VXtPSCgJseqC0M%3A&vet=1&w=480&h=360&source=sh%2Fx%2Fim")

            elif ".quotes" in msg.text:
                tanya = msg.text.replace(".quotes","")
                jawab = ("Manusia hendaknya mulai dari detik ini juga mengusahakan dengan tidak pernah jemu untuk memahami hakekat Kebajikan/kebenaran, Kekayaan, Kesenangan, dan Kebebasan. Manusia adalah Sang Raja bagi dirinya sendiri, ia adalah pemimpin dari tubuhnya, ia adalah penguasa dari pikirannya; maka dari itu, berusahalah untuk memahami hakekat penjelmaan ini","Janganlah pernah bersedih hati dilahirkan menjadi manusia, meskipun pada kelahiran yang dianggap paling hina; karena sesungguhnya amat sulit untuk bisa menjelma menjadi manusia. Berbahagialah menjadi manusia","Mereka yang telah melakukan kebajikan pun kebenaran, namun masih terikat dalam proses lahir dan mati, mereka ini belumlah memperoleh inti sari dari kebebasan","Kebajikan dan kebenaran itu laksana perahu yang dapat mengantarkan manusia untuk pergi ke surga","Mustahil ada persahabatan tanpa kesabaran hati, yang ada pastilah kemurkaan, marah dan dendam, maka dari itu pupuklah terus kesabaran di dalam hati masing-masing")
                jawaban = random.choice(jawab)
                cl.sendText(msg.to,jawaban)

            elif "/say-id " in msg.text:
                say = msg.text.replace("/say-id ","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
#-------------------------------------------------
            elif "/say-en " in msg.text:
                say = msg.text.replace("/say-en ","")
                lang = 'en'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
#------------------------------------------------

            elif "Ban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            wait ["blacklist"][target] = True
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success add blacklist . . .")
                        except:
                           pass
            elif "Unban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del wait ["blacklist"][target]
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success add to blacklist . . .")
                        except:
                           pass
#            elif ("Block" in msg.text):
#                 if msg.toType == 2:
#                     targets = []
#                     key = eval(msg.contentMetadata["MENTION"])
#                     key["MENTIONEES"][0]["M"]
#                     for x in key["MENTIONEES"]:
#                         targets.append(x["M"])
#                     for target in targets:
#                         try:
#                            cl.blockContact(target)
#                            cl.sendText(msg.to, "Success block contact . . .")
#                         except Exception as e:
#                            print e

            elif msg.text in ["Conban","Contactban","Contact ban"]:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing  Blacklist user . . .")
                else:
                    cl.sendText(msg.to,"Daftar Contact banlist . . .")
                    h = ""
                    for i in wait["blacklist"]:
                        h = cl.getContact(i)
                        M = Message()
                        M.to = msg.to
                        M.contentType = 13
                        M.contentMetadata = {'mid': i}
                        cl.sendMessage(M)

            elif msg.text in ['Blocklist']:
                blockedlist = cl.getBlockedContactIds()
                cl.sendText(msg.to, "Please wait...")
                kontak = cl.getContacts(blockedlist)
                num=1
                msgs="[User Blocked List]\n"
                for ids in kontak:
                    msgs+="\n%i. %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n\nTotal %i blocked user(s)" % len(kontak)
                cl.sendText(msg.to, msgs)

            elif msg.text in ["Clear ban","Unbanall","Clear banlist"]:
                wait["blacklist"] = {}
                cl.sendText(msg.to,"☑ Blacklist ready Cleared ☺ . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Ban"]:
                wait["wblacklist"] = True
                cl.sendText(msg.to,"send contact to blacklist . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Unban"]:
                wait["dblacklist"] = True
                cl.sendText(msg.to,"send contact to whitelist . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Ban on repeat","Ban:repeat"]:
                wait["rblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Banned . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Unban on repeat","Unban:repeat"]:
                wait["rdblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Unbanned . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Repeat:off","Repeat off"]:
                wait["rblacklist"] = False
                wait["rdblacklist"] = False
                cl.sendText(msg.to,"Turn off repeat . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Banlist"]:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing banlist user . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"Waiting . . . .!!!!\nChacking blacklist user . . . .")
                    num=1
                    mc = "User Blacklist\n"
                    for mi_d in wait["blacklist"]:
                        mc += "%i. %s\n" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc + "" + "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

            elif msg.text in ['Kbanlist']:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing banlist user . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"Waiting . . . .!!!!\nChacking blacklist user . . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    kontak = cl.getContacts(blacklist)
                    num=1
                    msgs="[User Black List]\n"
                    for ids in kontak:
                        msgs+="\n%i. %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n\nTotal %i blacklist user(s)" % len(kontak)
                    cl.sendText(msg.to, msgs)

            elif msg.text in ["Ban cek","Cekban","Bl check"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = "User Blacklist"
                    for mm in matched_list:
                        cocoa += "\n" + mm + "\n"
                    cl.sendText(msg.to, cocoa + "" +  "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

            elif msg.text in ["Kill ban"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"There was no blacklist user . . .")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        ki.kickoutFromGroup(msg.to,[jj])
                        kk.kickoutFromGroup(msg.to,[jj])
                        kc.kickoutFromGroup(msg.to,[jj])
                        cl.sendText(msg.to,"Refusing blacklist user . . .")
                        kc.sendText(msg.to, "Done refusing blacklist in groups . . .")

            elif msg.text in ["Bmid","banlistmid"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = "[⎈] Mid Banlist [⎈]"
                    for mm in matched_list:
                        cocoa += "\n" + mm + "\n"
                    cl.sendText(msg.to,cocoa + "")

#-----------------------------------------------
            elif msg.text in ["Stest","Sp","Speed"]:
                start = time.time()
                cl.sendText(msg.to, "Waiting speed progresss...\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
            elif msg.text in ["Allspeed"]:
                if msg.toType == 2:
                   start = time.time()
                   cl.sendText(msg.to, "Progress...")
                   elapsed_time = time.time() - start
                   cl.sendText(msg.to, "%sseconds" % (elapsed_time))
                   ki.sendText(msg.to, "%sseconds" % (elapsed_time))
                   kk.sendText(msg.to, "%sseconds" % (elapsed_time))
                   kc.sendText(msg.to, "%sseconds" % (elapsed_time))

            elif ("Cek" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getContact(key1)
                   cl.sendText(msg.to,"[Mid]    \n\n" +  key1)

            elif "Cium @" in msg.text:
                _name = msg.text.replace("Cium @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                       cl.sendText(msg.to,"ƠƬƜ ƧƤƛM ƬƛƦƓЄƬ 😂\n\n"+ datetime.today().strftime('%H:%M:%S'))
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       kf.sendText(g.mid,"Spam 😂")
                       kg.sendText(g.mid,"Spam 😂")                
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       kf.sendText(g.mid,"Spam 😂")
                       kg.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       kf.sendText(g.mid,"Spam 😂")
                       kg.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam ??")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kk.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kk.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam ??")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kf.sendText(g.mid,"Spam 😂")
                       kg.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam ??")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kk.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kk.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam ??")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"Spam 😂")
                       ke.sendText(g.mid,"Spam 😂")
                       cl.sendText(g.mid,"Spam 😂")
                       ki.sendText(g.mid,"Spam 😂")
                       kk.sendText(g.mid,"Spam 😂")
                       kd.sendText(g.mid,"Spam 😂")
                       kc.sendText(g.mid,"HƛHƛHƛ ƊƖ Cium 😂")
                       ke.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       cl.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       ki.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kk.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       kd.sendText(g.mid,"HƛHƛHƛ ƊƖ ƧƤƛM 😂")
                       cl.sendText(msg.to, "Sudah di Cium 😂\n\n"+ datetime.today().strftime('%H:%M:%S'))
                       print ("Done spam" )
#-----------------------------------------------
            elif msg.text in ["Restart"]:
                 cl.sendText(msg.to, "Succes Restarted")
                 restart_program()
                 print ("@Restart")

            elif msg.text.lower() == 'runtime':
                eltime = time.time()
                van = "Bot sudah berjalan selama "+waktu(eltime)
                cl.sendText(msg.to,van)
#----------------------------------------------

            elif "Getname @" in msg.text:
                 _name = msg.text.replace("Getname @","")
                 _nametarget = _name.rstrip(" ")
                 gs = cl.getGroup(msg.to)
                 for h in gs.members:
                   if _nametarget == h.displayName:
                      cl.sendText(msg.to,"[DisplayName]:\n" + h.displayName )
                   else:
                     pass
            elif "Getpre" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    cl.sendImageWithUrl(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithUrl(msg.to,path)
                except:
                    pass
            elif "Getbio @" in msg.text:
                 _name = msg.text.replace("Getbio @","")
                 _nametarget = _name.rstrip(" ")
                 gs = cl.getGroup(msg.to)
                 gs = cl.getProfile(msg.to)
                 for h in gs.members:
                   if _nametarget == h.displayName:
                      cl.sendText(msg.to,"[StatusMessage]:\n" + h.statusMessage)                 
                   else:
                     pass

            elif "Say-id: " in msg.text:
                    say = msg.text.replace("Say-id: ","")
                    lang = 'id'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")

            elif "Say-ja: " in msg.text:
                    say = msg.text.replace("Say-ja: ","")
                    lang = 'ja'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(msg.to,"hasil.mp3")

            elif "Say-en: " in msg.text:
                    say = msg.text.replace("Say-en: ","")
                    lang = 'en'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(msg.to,"hasil.mp3")
 
#---------------------------------------------------------------#

            elif msg.text in ["Tagmem","Tag","Tagall"]:
                group = cl.getGroup(msg.to)
                k = len(group.members)//100
                for j in xrange(k+1):
                    msg = Message(to=msg.to)
                    txt = u''
                    s=0
                    d=[]
                    for i in group.members[j*100 : (j+1)*100]:
                        d.append({"S":str(s), "E" :str(s+8), "M":i.mid})
                        s += 9
                        txt += u'@Neobots\n'
                    msg.text = txt
                    msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                    cl.sendMessage(msg)

            elif msg.text in ["S1tag","Bot1 tag","Neo1 tagall"]:
                if msg.toType == 2:
                    group = ki.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        ki.sendMessage(msg)
                    except Exception as error:
                        print (error)
            elif msg.text in ["Neo2 tagall","S2tag","Bot2 tag"]:
                if msg.toType == 2:
                    group = kk.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        kk.sendMessage(msg)
                    except Exception as error:
                        print (error)
            elif msg.text in ["Neo3 tagall","S3tag","Bot3 tag"]:
                if msg.toType == 2:
                    group = kc.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        kc.sendMessage(msg)
                    except Exception as error:
                        print (error)

#-----------------------------------------------
            elif "Mid @" in msg.text:
            	if msg.from_ in admin:
                  _name = msg.text.replace("Mid @","")
                  _nametarget = _name.rstrip(' ')
                  gs = cl.getGroup(msg.to)
                  for g in gs.members:
                      if _nametarget == g.displayName:
                          cl.sendText(msg.to, g.mid)
                      else:
                          pass

            elif '.music ' in msg.text.lower():
                cl.sendText(msg.to,"Tunggu...")
                try:
                    songname = msg.text.lower().replace('music ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Ini Dia Hasilnya\n'
                        hasil += 'Judul : ' + song[0]
                        hasil += '\nDurasi : ' + song[1]
                        hasil += '\nLink Download : ' + song[4]
                        cl.sendText(msg.to, hasil)
                        cl.sendText(msg.to, "Tunggu VN Musiknya...")
                        cl.sendAudioWithURL(msg.to, song[4])
                except Exception as njer:
                    cl.sendText(msg.to, str(njer))
            
            elif ".Youtube " in msg.text:
                 query = msg.text.replace(".Youtube ","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url    = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r    = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'http://www.youtube.com' + a['href'] + a['title'])

#-----------------------------------------------

            if wait["akaInvite"] == True:
                     if msg.from_ in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = cl.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName:
                                 ki.sendText(msg.to,"-> " + _name + " was here")
                                 break
                             elif invite in wait["blacklist"]:
                                 kk.sendText(msg.to,"Sorry, " + _name + " On Blacklist user")
                                 kc.sendText(msg.to,"Call my daddy to use command !, \n➡ Unban: " + invite)
                                 wait["akaInvite"] = True
                                 break
                             else:
                                 targets.append(invite)
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     cl.findAndAddContactsByMid(target)
                                     cl.inviteIntoGroup(msg.to, [target])
                                     ki.sendText(msg.to," Invited: \n➡ " + _name)
                                     wait["akaInvite"] = False
                                     break
                                 except:
                                        ki.sendText(msg.to,"Negative, Err0r Detected")
                                        wait["akaInvite"] = False
                                        break

        if op.type == 55:
          if wait["lurkingOn"] == True:
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n✑ " + Name + datetime.today().strftime(' [%d - %H:%M:%S]')
                        wait2['ROM'][op.param1][op.param2] = "✑ " + Name
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                else:
                    pass
            except:
                pass

        if op.type == 26:
            msg = op.message
            try:
                if msg.contentType == 0:
                    try:
                        if msg.to in wait2['readPoint']:
                            if msg.from_ in wait2["ROM"][msg.to]:
                                del wait2["ROM"][msg.to][msg.from_]
                        else:
                            pass
                    except:
                        pass
                else:
                    pass

            except KeyboardInterrupt:
                sys.exit(0)
            except Exception as error:
                print (error)
                print ("\n\nRECEIVE_MESSAGE\n\n")
                return

            if cms(msg.text,["#lurkcheck","#lurklist","Lurkers"]):
              if wait["lurkingOn"] == True:
                 if msg.toType == 2:
                    print ("\nSider check aktif...")
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        kc.sendText(msg.to, "[LURKER LIST]\n%s\n\nThese users have seen at the last lurking point . . .\n\n%s" % (wait2['readMember'][msg.to],setTime[msg.to]))
                        wait["lurkingOn"] = True
                        print ("\nReading Point Set...")
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        kc.sendText(msg.to, "Auto set lurking point . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        wait["lurkingOn"] = True
                        kc.sendText(msg.to, "Wait for set lurking point...\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                        print ("\nReading Point Set...")
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        kc.sendText(msg.to, "Lurking ready to check list\nSend「#lurkcheck」again")
                 else:
                     kc.sendText(msg.to, "Error..")

            if cms(msg.text,["#ban:on"]):
                if msg.toType == 2:
                    if msg.from_ in admin:
                        wait["wblacklist"] = True
                        random.choice(KAC2).sendText(msg.to,"Send Contact to Banned . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            if cms(msg.text,["#unban:on"]):
                if msg.toType == 2:
                    if msg.from_ in admin:
                        wait["dblacklist"] = True
                        random.choice(KAC2).sendText(msg.to,"Send Contact to Unbanned . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))


            elif msg.text is None:
                return
            elif msg.text in ["Bot help","#key"]:
                if msg.toType == 2:
                    if msg.from_ in admin:
#                        print "\nHelp staff command..."
                        if wait["lang"] == "JP":
                           aka = cl.getProfile().displayName
                           random.choice(KAC2).sendText(msg.to, "[⌛] Author of Neo: \n" + aka + "\n\n" + helpMessage3)
                        else:
                           random.choice(KAC2).sendText(msg.to, helpt)

#===========================================================================

#    #---Sc jika ada orang yg tag kita langsung di respon bot---
#            elif "@Pangeran_ÑÊØ Pangiri " in msg.text:
#                tanya = msg.text.replace("@Pangeran_ÑÊØ Pangiri ","")
#                jawab = ("Mainan tag mulu...","Orangnya lagi sibuk brader jangan tag mulu...,","Tag aja terus sampek kena bl line...  orang gak ada di tag.... ","Lagi mojok jangan di ganggu.  . . .","Kakak kalo kangen pm aja ya kak jangan ditag . . . Kan dia lagi sibuk kak.!!!","Kakak nakal ya aim di tag terus . . .","Tag yang lain bisa kan kak . . . .","Susah ya dibilangin jangan mainan tag . . .","AWASS . . .!!! limit tag 15 kena kick . . .","Ok fine . . .!!! Yang waras ngalah dech . . .","Kasian yah masa kecil kurang bahagia udah besat mainan tag . . .","Bandel banget sih . . . Anak siapa ini . . .?","Sungguh terlalu jaman kid now  . . .","Tag","Tagmem","Tagall")
 #               jawaban = random.choice(jawab)
#                cl.sendText(msg.to,jawaban)

#===============≠===============================================================
        if op.type == 55:
            print ("[NOTIFIED_READ_MESSAGE]")
            try:
                if op.param1 in wait2['readPoint']:
                    Nama = cl.getContact(op.param2).displayName
                    if Nama in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "╔════════════════╗\n╟ " + Nama
                        wait2['ROM'][op.param1][op.param2] = "╟" + Nama
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                else:
                    cl.sendText
            except:
                pass

        if op.type == 59:
            print (op)


    except Exception as error:
        print (error)

def autoSta():
    count = 1
    while True:
        try:
           for posts in cl.activity(1)["result"]["posts"]:
             if posts["postInfo"]["liked"] is False:
                if wait["likeOn"] == True:
                   cl.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   ki.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   kk.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   kc.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   ks.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   kt.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   if wait["commentOn"] == True:
                      if posts["userInfo"]["writerMid"] in wait["commentBlack"]:
                         pass
                      else:
                          cl.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
                          ki.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
                          kk.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
                          kc.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
                          ks.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
                          kt.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
        except:
            count += 1
            if(count == 50):
                sys.exit(0)
            else:
                pass
#thread1 = threading.Thread(target=autoSta)
#thread1.daemon = True
#thread1.start()

def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
def nameUpdate():
    while True:
        try:
            if wait["clock"] == True:
                now2 = datetime.now()
                nowT = datetime.strftime(now2,"(%H:%M)")
                profile = cl.getProfile()
                profile.displayName = wait["cName"] + nowT
                cl.updateProfile(profile)
            time.sleep(600)
        except:
            pass
thread2 = threading.Thread(target=nameUpdate)
thread2.daemon = True
thread2.start()

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
